﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PopUpFormRiwayatBarang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.closeBtn = New System.Windows.Forms.Button()
        Me.lbl_nmaKodeBarang = New System.Windows.Forms.Label()
        Me.dgv_tabelDetailRiwayat = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTglBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDSupRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNmaSupRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQtyRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgv_tabelDetailRiwayat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(29, 57)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(703, 2)
        Me.Label6.TabIndex = 63
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(26, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 23)
        Me.Label1.TabIndex = 62
        Me.Label1.Text = "Riwayat"
        '
        'closeBtn
        '
        Me.closeBtn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeBtn.ForeColor = System.Drawing.Color.Maroon
        Me.closeBtn.Location = New System.Drawing.Point(683, 15)
        Me.closeBtn.Name = "closeBtn"
        Me.closeBtn.Size = New System.Drawing.Size(49, 30)
        Me.closeBtn.TabIndex = 61
        Me.closeBtn.Text = "| X |"
        Me.closeBtn.UseVisualStyleBackColor = True
        '
        'lbl_nmaKodeBarang
        '
        Me.lbl_nmaKodeBarang.AutoSize = True
        Me.lbl_nmaKodeBarang.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_nmaKodeBarang.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lbl_nmaKodeBarang.Location = New System.Drawing.Point(119, 27)
        Me.lbl_nmaKodeBarang.Name = "lbl_nmaKodeBarang"
        Me.lbl_nmaKodeBarang.Size = New System.Drawing.Size(132, 18)
        Me.lbl_nmaKodeBarang.TabIndex = 64
        Me.lbl_nmaKodeBarang.Text = "<Nama Barang>"
        '
        'dgv_tabelDetailRiwayat
        '
        Me.dgv_tabelDetailRiwayat.AllowUserToAddRows = False
        Me.dgv_tabelDetailRiwayat.AllowUserToDeleteRows = False
        Me.dgv_tabelDetailRiwayat.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_tabelDetailRiwayat.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv_tabelDetailRiwayat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_tabelDetailRiwayat.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.colTglBeliRiwayat, Me.colNoBeliRiwayat, Me.colIDSupRiwayat, Me.colNmaSupRiwayat, Me.colQtyRiwayat, Me.colHargaBeliRiwayat, Me.colTotalRiwayat})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_tabelDetailRiwayat.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgv_tabelDetailRiwayat.Location = New System.Drawing.Point(30, 76)
        Me.dgv_tabelDetailRiwayat.Name = "dgv_tabelDetailRiwayat"
        Me.dgv_tabelDetailRiwayat.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_tabelDetailRiwayat.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv_tabelDetailRiwayat.RowHeadersVisible = False
        Me.dgv_tabelDetailRiwayat.Size = New System.Drawing.Size(702, 347)
        Me.dgv_tabelDetailRiwayat.TabIndex = 65
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.HeaderText = "#"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 44
        '
        'colTglBeliRiwayat
        '
        Me.colTglBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTglBeliRiwayat.HeaderText = "Tgl. Beli"
        Me.colTglBeliRiwayat.Name = "colTglBeliRiwayat"
        Me.colTglBeliRiwayat.ReadOnly = True
        Me.colTglBeliRiwayat.Width = 84
        '
        'colNoBeliRiwayat
        '
        Me.colNoBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNoBeliRiwayat.HeaderText = "No. Pembelian"
        Me.colNoBeliRiwayat.Name = "colNoBeliRiwayat"
        Me.colNoBeliRiwayat.ReadOnly = True
        '
        'colIDSupRiwayat
        '
        Me.colIDSupRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIDSupRiwayat.HeaderText = "Supplier ID"
        Me.colIDSupRiwayat.Name = "colIDSupRiwayat"
        Me.colIDSupRiwayat.ReadOnly = True
        Me.colIDSupRiwayat.Width = 103
        '
        'colNmaSupRiwayat
        '
        Me.colNmaSupRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNmaSupRiwayat.HeaderText = "Nama Supplier"
        Me.colNmaSupRiwayat.Name = "colNmaSupRiwayat"
        Me.colNmaSupRiwayat.ReadOnly = True
        Me.colNmaSupRiwayat.Width = 126
        '
        'colQtyRiwayat
        '
        Me.colQtyRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colQtyRiwayat.HeaderText = "Qty"
        Me.colQtyRiwayat.Name = "colQtyRiwayat"
        Me.colQtyRiwayat.ReadOnly = True
        Me.colQtyRiwayat.Width = 57
        '
        'colHargaBeliRiwayat
        '
        Me.colHargaBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colHargaBeliRiwayat.HeaderText = "Harga Beli"
        Me.colHargaBeliRiwayat.Name = "colHargaBeliRiwayat"
        Me.colHargaBeliRiwayat.ReadOnly = True
        Me.colHargaBeliRiwayat.Width = 98
        '
        'colTotalRiwayat
        '
        Me.colTotalRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotalRiwayat.HeaderText = "Total"
        Me.colTotalRiwayat.Name = "colTotalRiwayat"
        Me.colTotalRiwayat.ReadOnly = True
        Me.colTotalRiwayat.Width = 66
        '
        'PopUpFormRiwayatBarang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(760, 454)
        Me.Controls.Add(Me.dgv_tabelDetailRiwayat)
        Me.Controls.Add(Me.lbl_nmaKodeBarang)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.closeBtn)
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "PopUpFormRiwayatBarang"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PopUpFormRiwayatBarang"
        CType(Me.dgv_tabelDetailRiwayat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents closeBtn As Button
    Friend WithEvents lbl_nmaKodeBarang As Label
    Friend WithEvents dgv_tabelDetailRiwayat As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents colTglBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNoBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colIDSupRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNmaSupRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colQtyRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colHargaBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colTotalRiwayat As DataGridViewTextBoxColumn
End Class

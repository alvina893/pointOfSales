﻿Imports System.Runtime.InteropServices
Imports MySql.Data.MySqlClient

Public Class frm_KonfirmasiPengembalian

    <DllImport("dwmapi.dll")>
    Private Shared Function DwmExtendFrameIntoClientArea(hWnd As IntPtr, ByRef pMarInset As MARGINS) As Integer
    End Function

    <DllImport("dwmapi.dll")>
    Private Shared Function DwmSetWindowAttribute(hwnd As IntPtr, attr As Integer, ByRef attrValue As Integer, attrSize As Integer) As Integer
    End Function
    Structure MARGINS
        Public Left As Integer
        Public Right As Integer
        Public Top As Integer
        Public Bottom As Integer
    End Structure

    Private Sub EnableShadow()
        Dim val As Integer = 2 ' DWMNCRP_ENABLED
        DwmSetWindowAttribute(Me.Handle, 2, val, 4)

        Dim m As New MARGINS With {
        .Left = 1,
        .Right = 1,
        .Top = 1,
        .Bottom = 1
    }
        DwmExtendFrameIntoClientArea(Me.Handle, m)
    End Sub

    Private Sub frm_KonfirmasiPengembalian_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbconn()
        EnableShadow()
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        Me.Close()
    End Sub

    Public Sub LoadDetailPengembalian(noPengembalian As String)
        Try
            If conn Is Nothing Then dbconn() ' Jaga-jaga jika conn nothing
            If conn.State = ConnectionState.Closed Then conn.Open()

            dgv_tabelDetailPengembalian.Rows.Clear()

            Dim sql As String =
        "SELECT kode_barang, barcode_value, nama_barang,
                qty, satuan, harga, subtotal
         FROM tbldetailpengembalian
         WHERE no_pengembalian=@no"

            Using cmd As New MySqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@no", noPengembalian)

                Using dr = cmd.ExecuteReader()
                    Dim no As Integer = 1
                    While dr.Read()
                        dgv_tabelDetailPengembalian.Rows.Add(
                        no,
                        dr("kode_barang"),
                        dr("barcode_value"),
                        dr("nama_barang"),
                        dr("qty"),
                        dr("satuan"),
                        Format(CDec(dr("harga")), "N0"),
                        Format(CDec(dr("subtotal")), "N0")
                    )
                        no += 1
                    End While
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close() ' Selalu tutup koneksi setelah selesai mengambil data
        End Try
    End Sub

    Sub ProsesFIFO(noPengembalian As String,
               kodeBarang As String,
               qtyRetur As Integer,
               conn As MySqlConnection,
               trans As MySqlTransaction)

        Dim sisaQty As Integer = qtyRetur
        Dim dtBatch As New DataTable()

        ' Ambil batch FIFO
        Dim sqlBatch As String =
            "SELECT 
                d.detailpembelian_ID,
                d.qty
             FROM tbldetailpembelian d
             JOIN tblpembelian p ON d.no_pembelian = p.no_pembelian
             WHERE d.kode_barang = @kode
               AND d.qty > 0
             ORDER BY p.tanggal ASC"

        Using da As New MySqlDataAdapter(sqlBatch, conn)
            da.SelectCommand.Transaction = trans
            da.SelectCommand.Parameters.AddWithValue("@kode", kodeBarang)
            da.Fill(dtBatch)
        End Using

        ' Ambil detail retur (SUDAH ADA)
        Dim detailReturID As Integer
        Using cmdGet As New MySqlCommand(
        "SELECT detailpengembalian_ID 
         FROM tbldetailpengembalian
         WHERE no_pengembalian=@no
           AND kode_barang=@kode
         LIMIT 1", conn, trans)

            cmdGet.Parameters.AddWithValue("@no", noPengembalian)
            cmdGet.Parameters.AddWithValue("@kode", kodeBarang)
            detailReturID = CInt(cmdGet.ExecuteScalar())
        End Using

        For Each row As DataRow In dtBatch.Rows
            If sisaQty <= 0 Then Exit For

            Dim detailPembelianID As Integer = CInt(row("detailpembelian_ID"))
            Dim stokBatch As Integer = CInt(row("qty"))
            Dim pakaiQty As Integer = Math.Min(stokBatch, sisaQty)

            ' 1. UPDATE relasi batch pembelian
            Using cmdUpdDetail As New MySqlCommand(
            "UPDATE tbldetailpengembalian
             SET detailpembelian_ID = @detailPembelianID
             WHERE detailpengembalian_ID = @id", conn, trans)

                cmdUpdDetail.Parameters.AddWithValue("@detailPembelianID", detailPembelianID)
                cmdUpdDetail.Parameters.AddWithValue("@id", detailReturID)
                cmdUpdDetail.ExecuteNonQuery()
            End Using

            ' 2. KURANGI stok pembelian
            Using cmdUpdStok As New MySqlCommand(
            "UPDATE tbldetailpembelian
             SET qty = qty - @qty
             WHERE detailpembelian_ID = @id", conn, trans)

                cmdUpdStok.Parameters.AddWithValue("@qty", pakaiQty)
                cmdUpdStok.Parameters.AddWithValue("@id", detailPembelianID)
                cmdUpdStok.ExecuteNonQuery()
            End Using

            sisaQty -= pakaiQty
        Next

        If sisaQty > 0 Then
            Throw New Exception("Stok pembelian tidak mencukupi untuk retur")
        End If
    End Sub

    Private Sub btn_konfirmPengembalian_Click(sender As Object, e As EventArgs) Handles btn_konfirmPengembalian.Click
        If cbo_metodeRetur.SelectedItem Is Nothing Then
            MsgBox("Pilih metode pengembalian!", vbExclamation)
            Exit Sub
        End If

        Dim metode As String = cbo_metodeRetur.SelectedItem.ToString()
        Dim noPengembalian As String = lbl_noPengembalianAjukan.Text
        Dim trans As MySqlTransaction = Nothing

        Try

            Dim totalDana As Decimal = CDec(lbl_totalDanaPengembalianAjukan.Text)
            Dim totalStok As Integer = CInt(lbl_totalStokPengembalianAjukan.Text)

            If metode = "Refund (Dana)" Then
                totalStok = 0        ' Dana → tidak ada stok kembali
            ElseIf metode = "Tukar Guling (Barang)" Then
                totalDana = 0        ' Barang → tidak ada dana kembali
            End If

            If conn.State = ConnectionState.Closed Then conn.Open()
            trans = conn.BeginTransaction()

            ' 1. UPDATE HEADER
            Using cmd As New MySqlCommand(
                "UPDATE tblpengembalian
                 SET metode_pengembalian=@metode,
                     total_returDana=@dana,
                     total_returStok=@stok,
                     status_pengembalian='Konfirmasi'
                 WHERE no_pengembalian=@no", conn, trans)

                cmd.Parameters.AddWithValue("@metode", metode)
                cmd.Parameters.AddWithValue("@dana", totalDana)
                cmd.Parameters.AddWithValue("@stok", totalStok)
                cmd.Parameters.AddWithValue("@no", noPengembalian)
                cmd.ExecuteNonQuery()
            End Using

            ' 2. LOGIKA BERDASARKAN METODE
            If metode = "Refund (Dana)" Then

                ' 🔥 FIFO → kurangi stok pembelian
                For Each row As DataGridViewRow In dgv_tabelDetailPengembalian.Rows
                    If row.IsNewRow Then Continue For

                    ProsesFIFO(
            noPengembalian,
            row.Cells("colKodeBrg").Value.ToString(),
            CInt(row.Cells("colQty").Value),
            conn, trans
        )
                Next

            ElseIf metode = "Tukar Guling (Barang)" Then

                For Each row As DataGridViewRow In dgv_tabelDetailPengembalian.Rows
                    If row.IsNewRow Then Continue For

                    Dim kodeBarang As String = row.Cells("colKodeBrg").Value.ToString()
                    Dim qty As Integer = CInt(row.Cells("colQty").Value)

                    ' 🔥 1. FIFO → kurangi stok pembelian lama
                    ProsesFIFO(
            noPengembalian,
            kodeBarang,
            qty,
            conn, trans
        )

                    ' ➕ 2. Tambah stok barang (barang pengganti)
                    Using cmdUpd As New MySqlCommand(
            "UPDATE tblbarang
             SET stok = stok + @qty
             WHERE kode_barang=@kode", conn, trans)

                        cmdUpd.Parameters.AddWithValue("@qty", qty)
                        cmdUpd.Parameters.AddWithValue("@kode", kodeBarang)
                        cmdUpd.ExecuteNonQuery()
                    End Using
                Next
            End If
            trans.Commit()
            MsgBox("Pengembalian berhasil dikonfirmasi", vbInformation)
            Me.Close()
        Catch ex As Exception
            If trans IsNot Nothing Then trans.Rollback()
            MsgBox("Gagal konfirmasi: " & ex.Message, vbCritical)
        Finally
            conn.Close()
            frm_ManagePengembalian.load_ListPengembalian()
        End Try
    End Sub

    Private Sub dgv_tabelDetailPengembalian_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_tabelDetailPengembalian.CellContentClick
        If e.RowIndex < 0 Then Exit Sub

        If e.ColumnIndex = dgv_tabelDetailPengembalian.Columns("colLihatRiwayat").Index Then

            Dim kodeBarang As String =
            dgv_tabelDetailPengembalian.Rows(e.RowIndex).
            Cells("colKodeBrg").Value.ToString()

            Dim namaBarang As String =
            dgv_tabelDetailPengembalian.Rows(e.RowIndex).
            Cells("colNmaBrg").Value.ToString()

            Dim qty As Integer =
            CInt(dgv_tabelDetailPengembalian.Rows(e.RowIndex).
            Cells("colQty").Value)

            ' buka popup riwayat
            Dim frm As New PopUpFormRiwayatBarang
            frm.load_RiwayatBarang(kodeBarang, namaBarang, qty)
            frm.ShowDialog()
        End If
    End Sub
End Class
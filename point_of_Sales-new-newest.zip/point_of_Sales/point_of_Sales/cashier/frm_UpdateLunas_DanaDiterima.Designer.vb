﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_UpdateLunas_DanaDiterima
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_updateJualPending = New System.Windows.Forms.Button()
        Me.txt_danaPENDING = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.closeBtn = New System.Windows.Forms.Button()
        Me.lbl_kembalianPENDING = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lbl_totalPENDING = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_noPenjualanPENDING = New System.Windows.Forms.Label()
        Me.cbo_metodePembayaran = New System.Windows.Forms.ComboBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(40, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(320, 2)
        Me.Label6.TabIndex = 57
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(36, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 23)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "Update LUNAS"
        '
        'btn_updateJualPending
        '
        Me.btn_updateJualPending.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btn_updateJualPending.FlatAppearance.BorderSize = 0
        Me.btn_updateJualPending.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_updateJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updateJualPending.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_updateJualPending.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateJualPending.Location = New System.Drawing.Point(40, 401)
        Me.btn_updateJualPending.Name = "btn_updateJualPending"
        Me.btn_updateJualPending.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_updateJualPending.Size = New System.Drawing.Size(320, 29)
        Me.btn_updateJualPending.TabIndex = 55
        Me.btn_updateJualPending.Text = "Update LUNAS 💾"
        Me.btn_updateJualPending.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateJualPending.UseVisualStyleBackColor = False
        '
        'txt_danaPENDING
        '
        Me.txt_danaPENDING.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_danaPENDING.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_danaPENDING.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_danaPENDING.Location = New System.Drawing.Point(40, 281)
        Me.txt_danaPENDING.Name = "txt_danaPENDING"
        Me.txt_danaPENDING.Size = New System.Drawing.Size(320, 26)
        Me.txt_danaPENDING.TabIndex = 54
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(37, 262)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(124, 16)
        Me.Label10.TabIndex = 53
        Me.Label10.Text = "Dana yang Diterima:"
        '
        'closeBtn
        '
        Me.closeBtn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeBtn.ForeColor = System.Drawing.Color.Maroon
        Me.closeBtn.Location = New System.Drawing.Point(311, 12)
        Me.closeBtn.Name = "closeBtn"
        Me.closeBtn.Size = New System.Drawing.Size(49, 30)
        Me.closeBtn.TabIndex = 52
        Me.closeBtn.Text = "| X |"
        Me.closeBtn.UseVisualStyleBackColor = True
        '
        'lbl_kembalianPENDING
        '
        Me.lbl_kembalianPENDING.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_kembalianPENDING.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_kembalianPENDING.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_kembalianPENDING.Location = New System.Drawing.Point(35, 348)
        Me.lbl_kembalianPENDING.Name = "lbl_kembalianPENDING"
        Me.lbl_kembalianPENDING.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_kembalianPENDING.Size = New System.Drawing.Size(320, 27)
        Me.lbl_kembalianPENDING.TabIndex = 58
        Me.lbl_kembalianPENDING.Text = "00.00"
        Me.lbl_kembalianPENDING.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(37, 332)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 16)
        Me.Label2.TabIndex = 59
        Me.Label2.Text = "Kembalian:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(37, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 16)
        Me.Label3.TabIndex = 61
        Me.Label3.Text = "Yang Harus Dibayar:"
        '
        'lbl_totalPENDING
        '
        Me.lbl_totalPENDING.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_totalPENDING.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_totalPENDING.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lbl_totalPENDING.Location = New System.Drawing.Point(40, 150)
        Me.lbl_totalPENDING.Name = "lbl_totalPENDING"
        Me.lbl_totalPENDING.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_totalPENDING.Size = New System.Drawing.Size(320, 27)
        Me.lbl_totalPENDING.TabIndex = 60
        Me.lbl_totalPENDING.Text = "00.00"
        Me.lbl_totalPENDING.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(37, 71)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(140, 16)
        Me.Label4.TabIndex = 63
        Me.Label4.Text = "No. Penjualan Pending:"
        '
        'lbl_noPenjualanPENDING
        '
        Me.lbl_noPenjualanPENDING.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_noPenjualanPENDING.Font = New System.Drawing.Font("Tahoma", 16.0!)
        Me.lbl_noPenjualanPENDING.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_noPenjualanPENDING.Location = New System.Drawing.Point(40, 87)
        Me.lbl_noPenjualanPENDING.Name = "lbl_noPenjualanPENDING"
        Me.lbl_noPenjualanPENDING.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_noPenjualanPENDING.Size = New System.Drawing.Size(320, 27)
        Me.lbl_noPenjualanPENDING.TabIndex = 62
        Me.lbl_noPenjualanPENDING.Text = "00.00"
        Me.lbl_noPenjualanPENDING.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cbo_metodePembayaran
        '
        Me.cbo_metodePembayaran.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_metodePembayaran.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.cbo_metodePembayaran.FormattingEnabled = True
        Me.cbo_metodePembayaran.Items.AddRange(New Object() {"Tunai", "Non-Tunai"})
        Me.cbo_metodePembayaran.Location = New System.Drawing.Point(40, 216)
        Me.cbo_metodePembayaran.Name = "cbo_metodePembayaran"
        Me.cbo_metodePembayaran.Size = New System.Drawing.Size(320, 26)
        Me.cbo_metodePembayaran.TabIndex = 65
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label21.Location = New System.Drawing.Point(37, 197)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(129, 16)
        Me.Label21.TabIndex = 64
        Me.Label21.Text = "Metode Pembayaran:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frm_UpdateLunas_DanaDiterima
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(393, 455)
        Me.Controls.Add(Me.cbo_metodePembayaran)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lbl_noPenjualanPENDING)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lbl_totalPENDING)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbl_kembalianPENDING)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_updateJualPending)
        Me.Controls.Add(Me.txt_danaPENDING)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.closeBtn)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_UpdateLunas_DanaDiterima"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_UpdateLunas_DanaDiterima"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_updateJualPending As Button
    Friend WithEvents txt_danaPENDING As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents closeBtn As Button
    Friend WithEvents lbl_kembalianPENDING As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbl_totalPENDING As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lbl_noPenjualanPENDING As Label
    Friend WithEvents cbo_metodePembayaran As ComboBox
    Friend WithEvents Label21 As Label
End Class

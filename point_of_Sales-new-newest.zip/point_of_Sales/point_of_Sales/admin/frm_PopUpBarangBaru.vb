﻿Imports System.IO
Imports System.Runtime.InteropServices
Imports MessagingToolkit.Barcode
Imports MySql.Data.MySqlClient

Public Class frm_PopUpBarangBaru

    <DllImport("dwmapi.dll")>
    Private Shared Function DwmExtendFrameIntoClientArea(hWnd As IntPtr, ByRef pMarInset As MARGINS) As Integer
    End Function

    <DllImport("dwmapi.dll")>
    Private Shared Function DwmSetWindowAttribute(hwnd As IntPtr, attr As Integer, ByRef attrValue As Integer, attrSize As Integer) As Integer
    End Function
    Structure MARGINS
        Public Left As Integer
        Public Right As Integer
        Public Top As Integer
        Public Bottom As Integer
    End Structure

    Sub GenerateKodeBarang()
        Dim prefix As String = "IM-BRG-"
        Dim newIncrement As Integer = 1

        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()

            Dim query As String =
            "SELECT IFNULL(MAX(CAST(RIGHT(kode_barang,3) AS UNSIGNED)),0)
             FROM tblbarang
             WHERE kode_barang LIKE 'IM-BRG-%'"

            Dim cmd As New MySqlCommand(query, conn)
            Dim result = cmd.ExecuteScalar()

            newIncrement = CInt(result) + 1

        Catch ex As Exception
            MsgBox("Error generate kode barang: " & ex.Message)
        Finally
            conn.Close()
        End Try

        txt_kodeBrg.Text = prefix & newIncrement.ToString("000")
        txt_kodeBrg.ReadOnly = True
    End Sub


    Sub load_kategoriBarang()
        cbo_kategoriBrg.Items.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT * from `tblkategori`", conn)
            dr = cmd.ExecuteReader
            While dr.Read = True
                cbo_kategoriBrg.Items.Add(dr.Item("nma_kategori").ToString)
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Sub load_satuanBarang()
        cbo_satuanBrg.Items.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT * from `tblsatuan`", conn)
            dr = cmd.ExecuteReader
            While dr.Read = True
                cbo_satuanBrg.Items.Add(dr.Item("nma_satuan").ToString)
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Dim supplierDict As New Dictionary(Of String, String)

    Sub load_supplier()
        cbo_idSup.Items.Clear()
        supplierDict.Clear()

        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT supplier_ID, nama_supplier FROM tblsupplier", conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim id As String = dr("supplier_ID").ToString()
                Dim nama As String = dr("nama_supplier").ToString()

                cbo_idSup.Items.Add(id)           ' Display name
                supplierDict(id) = nama              ' Store ID for later
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        Me.Close()
    End Sub

    Private Sub EnableShadow()
        Dim val As Integer = 2 ' DWMNCRP_ENABLED
        DwmSetWindowAttribute(Me.Handle, 2, val, 4)

        Dim m As New MARGINS With {
        .Left = 1,
        .Right = 1,
        .Top = 1,
        .Bottom = 1
    }
        DwmExtendFrameIntoClientArea(Me.Handle, m)
    End Sub
    Private Sub frm_PopUpBarangBaru_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbconn()
        EnableShadow()

        load_kategoriBarang()
        load_satuanBarang()
        load_supplier()
        GenerateKodeBarang()

        pic_barcodeBrg.Visible = False
        lblgenerateBarcode.Visible = False
        btn_printBarcodeBarang.Visible = False
    End Sub

    Private Sub btn_tmbhKategori_Click(sender As Object, e As EventArgs) Handles btn_tmbhKategori.Click
        Using fSatuan As New frm_tbhKategori
            fSatuan.ShowDialog(Me)  ' Me = form Tambah Barang sebagai parent
        End Using
    End Sub

    Private Sub btn_tmbhSatuan_Click(sender As Object, e As EventArgs) Handles btn_tmbhSatuan.Click
        Using fSatuan As New frm_tbhSatuan
            fSatuan.ShowDialog(Me)  ' Me = form Tambah Barang sebagai parent
        End Using
    End Sub

    Private Sub txt_kodeBrg_TextChanged(sender As Object, e As EventArgs) Handles txt_kodeBrg.TextChanged
        Dim Generator As New MessagingToolkit.Barcode.BarcodeEncoder
        Generator.BackColor = Color.White

        Try
            pic_barcodeBrg.Image = New Bitmap(Generator.Encode(MessagingToolkit.Barcode.BarcodeFormat.Code93, txt_kodeBrg.Text))

        Catch ex As Exception
            pic_barcodeBrg.Image = Nothing
        End Try
    End Sub

    Private Sub cbo_nmaSup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_idSup.SelectedIndexChanged
        Dim id As String = cbo_idSup.Text

        If supplierDict.ContainsKey(id) Then
            txt_namaSup.Text = supplierDict(id)
        End If
    End Sub

    Function cekBarangViaKode(kode As String) As Boolean
        Dim ada As Boolean = False

        Try
            conn.Open()
            Dim cmd As New MySqlCommand("SELECT COUNT(*) FROM tblbarang WHERE kode_barang=@kode", conn)
            cmd.Parameters.AddWithValue("@kode", kode)

            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            ada = (count > 0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        Return ada
    End Function

    Sub clear()
        txt_kodeBrg.Clear()
        txt_nmaBrg.Clear()
        cbo_kategoriBrg.SelectedIndex = -1
        cbo_satuanBrg.SelectedIndex = -1
        cbo_idSup.SelectedIndex = -1
        txt_namaSup.Clear()
        txt_hrgaBrg.Clear()
        txt_hrgaBeli.Clear()
        txt_stok.Clear()
        txt_minStok.Clear()
        pic_barcodeBrg.Image = Nothing
    End Sub

    Private Sub btn_simpanBrg_Click(sender As Object, e As EventArgs) Handles btn_simpanBrg.Click
        Try
            If cekBarangViaKode(txt_kodeBrg.Text) Then
                MsgBox("Kode barang sudah terdaftar! Gunakan tombol UPDATE untuk mengubah data.", vbExclamation)
                Exit Sub
            End If

            If String.IsNullOrWhiteSpace(txt_barcodeValue.Text) Then
                MsgBox("Barcode belum diisi / discan!", vbExclamation)
                Exit Sub
            End If

            conn.Open()
            Dim arrImage() As Byte = Nothing
            If cbo_tipeBarcode.Text = "Generate Barcode" Then
                If pic_barcodeBrg.Image IsNot Nothing Then
                    Using mstream As New MemoryStream()
                        pic_barcodeBrg.Image.Save(mstream, Imaging.ImageFormat.Png)
                        arrImage = mstream.ToArray()
                    End Using
                End If
            End If

            cmd = New MySqlCommand("INSERT INTO `tblbarang`(`kode_barang`, `barcode_value`, `barcode_type`, `nama_barang`, `kategori_barang`, `satuan_barang`, `harga_beli`, `harga_barang`, `stok`, `min_stok`, `barcode`, `supplier_ID`, `nama_supplier`) VALUES (@kode_barang, @barcode_value, @barcode_type, @nama_barang, @kategori_barang, @satuan_barang, @harga_beli, @harga_barang, @stok, @min_stok, @barcode, @supplier_ID, @nama_supplier)", conn)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@kode_barang", txt_kodeBrg.Text)
            cmd.Parameters.AddWithValue("@barcode_value", txt_barcodeValue.Text)
            cmd.Parameters.AddWithValue("@barcode_type", cbo_tipeBarcode.Text)
            cmd.Parameters.AddWithValue("@nama_barang", txt_nmaBrg.Text)
            cmd.Parameters.AddWithValue("@kategori_barang", cbo_kategoriBrg.Text)
            cmd.Parameters.AddWithValue("@satuan_barang", cbo_satuanBrg.Text)
            cmd.Parameters.AddWithValue("@harga_beli", CDec(txt_hrgaBeli.Text))
            cmd.Parameters.AddWithValue("@harga_barang", CDec(txt_hrgaBrg.Text))
            cmd.Parameters.AddWithValue("@stok", txt_stok.Text)
            cmd.Parameters.AddWithValue("@min_stok", txt_minStok.Text)
            If arrImage IsNot Nothing Then
                cmd.Parameters.Add("@barcode", MySqlDbType.Blob).Value = arrImage
            Else
                cmd.Parameters.Add("@barcode", MySqlDbType.Blob).Value = DBNull.Value
            End If
            cmd.Parameters.AddWithValue("@supplier_ID", cbo_idSup.Text)
            cmd.Parameters.AddWithValue("@nama_supplier", txt_namaSup.Text)

            i = cmd.ExecuteNonQuery
            If i > 0 Then
                MsgBox("Barang baru berhasil disimpan!", vbInformation)
            Else
                MsgBox("Barang gagal disimpan!", vbExclamation)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
        clear()
        frm_ManagePembelian.load_barang()
        Me.Close()
    End Sub

    Private Sub btn_delBrg_Click(sender As Object, e As EventArgs) Handles btn_delBrg.Click
        Me.Close()
    End Sub

    Private isLoadingData As Boolean = False
    Dim isManualBarcodeInput As Boolean = False

    Sub GenerateBarcodeFromKode()
        If txt_barcodeValue.Text = "" Then Exit Sub

        Dim gen As New MessagingToolkit.Barcode.BarcodeEncoder
        gen.BackColor = Color.White

        pic_barcodeBrg.Image =
        New Bitmap(gen.Encode(BarcodeFormat.Code128, txt_barcodeValue.Text))
    End Sub


    Private Sub txt_scanBarcode_TextChanged(sender As Object, e As EventArgs) Handles txt_barcodeValue.TextChanged
        If isLoadingData Then Exit Sub

        If isManualBarcodeInput AndAlso Not String.IsNullOrWhiteSpace(txt_barcodeValue.Text) Then
            isLoadingData = True
            isManualBarcodeInput = True
            cbo_tipeBarcode.SelectedItem = "Barcode dari Barang"
            isLoadingData = False
        End If
    End Sub

    Private Sub cbo_tipeBarcode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_tipeBarcode.SelectedIndexChanged
        If isLoadingData Then Exit Sub   ' ⛔ abaikan jika dari dgv click

        pic_barcodeBrg.Image = Nothing
        txt_barcodeValue.Clear()

        Select Case cbo_tipeBarcode.Text
            Case "Generate Barcode"
                isManualBarcodeInput = False
                txt_barcodeValue.Clear()
                pic_barcodeBrg.Visible = True
                btn_printBarcodeBarang.Visible = True
                lblgenerateBarcode.Visible = True

                txt_barcodeValue.Text = txt_kodeBrg.Text

                ' Barcode diambil dari kode_barang
                GenerateBarcodeFromKode()

            Case "Barcode dari Barang"
                isManualBarcodeInput = True
                txt_barcodeValue.Enabled = True
                pic_barcodeBrg.Visible = False
                btn_printBarcodeBarang.Visible = False
                lblgenerateBarcode.Visible = False

                txt_barcodeValue.Focus()
        End Select
    End Sub

    Private Sub txt_barcodeValue_Enter(sender As Object, e As EventArgs) Handles txt_barcodeValue.Enter
        If isLoadingData Then Exit Sub

        isManualBarcodeInput = True
        cbo_tipeBarcode.SelectedItem = "Barcode dari Barang"
    End Sub

    Private Sub frm_PopUpBarangBaru_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        txt_barcodeValue.Focus()
    End Sub
End Class
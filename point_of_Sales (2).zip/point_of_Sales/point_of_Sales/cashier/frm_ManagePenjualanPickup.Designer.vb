﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_ManagePenjualanPickup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_ManagePenjualanPickup))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.closeBtn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnSemuaListPenjualan = New System.Windows.Forms.Button()
        Me.btnPickup = New System.Windows.Forms.Button()
        Me.btnDelivery = New System.Windows.Forms.Button()
        Me.btnPOS_Kasir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnCancelPickup = New System.Windows.Forms.Button()
        Me.pic_barcodePenjualanPickup = New System.Windows.Forms.PictureBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txt_kontakDeliveryPickup = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txt_atasNamaDeliveryPickup = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtJenisDeliveryPickup = New System.Windows.Forms.TextBox()
        Me.cbo_statusPickup = New System.Windows.Forms.ComboBox()
        Me.txt_noPenjualanPickup = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txt_catatanPickup = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbl_totalQtyPickup = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.cbo_metodePembayaranPickup = New System.Windows.Forms.ComboBox()
        Me.btn_simpanPenjualanPickup = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.cbo_statusPenjualanPickup = New System.Windows.Forms.ComboBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lbl_subTotalPickup = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lbl_hargaSatuanPickup = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lbl_QtyPickup = New System.Windows.Forms.Label()
        Me.lbl_grandTotalPickup = New System.Windows.Forms.Label()
        Me.lbl_noPenjualanPickup = New System.Windows.Forms.Label()
        Me.txt_danaDiterimaPickup = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lbl_kembalianPickup = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lst_pickupResult = New System.Windows.Forms.ListBox()
        Me.txt_pickupSearchBrng = New System.Windows.Forms.TextBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.txt_satuanBrgPickup = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txt_namaBrgPickup = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.cbo_brgPickup = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txt_subTotalPickup = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_hrgaPickup = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_qtyPickup = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btn_tmbhDetBeliPickup = New System.Windows.Forms.Button()
        Me.dgv_detailPenjualanPickup = New System.Windows.Forms.DataGridView()
        Me.colNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKodeBrg = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNmaBrg = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSatuan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHarga = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSubtotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBarcodePickup = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dtp_tglJualPickup = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgv_listPenjualanPending = New System.Windows.Forms.DataGridView()
        Me.colNmr = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoPenjualan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colJenis = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTglPembelian = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalPenjualan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDanaDiterima = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKembalian = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMetodePembayaran = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatatan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAtasN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKontak = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatusPKirim = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.txt_cariPenjualan = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.lbl_catatanPending = New System.Windows.Forms.RichTextBox()
        Me.lbl_statusKirimPending = New System.Windows.Forms.Label()
        Me.lbl_kontakPending = New System.Windows.Forms.Label()
        Me.lbl_atasNamaPending = New System.Windows.Forms.Label()
        Me.lbl_jenisJualPending = New System.Windows.Forms.Label()
        Me.pnl_listDetail = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.rtb_detailPenjualan = New System.Windows.Forms.RichTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lbl_statusJualPending = New System.Windows.Forms.Label()
        Me.lbl_metodeJualPending = New System.Windows.Forms.Label()
        Me.lbl_totalJualPending = New System.Windows.Forms.Label()
        Me.lbl_tglJualPending = New System.Windows.Forms.Label()
        Me.lbl_noJualPending = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btn_clearPenjualanPending = New System.Windows.Forms.Button()
        Me.btn_updateLunasPenjualan = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.dgv_penjualanPackingPickup = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoPenjualanPickupPacking = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.txtCariPenjualanPacking = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.lbl_catatanPacking = New System.Windows.Forms.RichTextBox()
        Me.lbl_statusKirimPacking = New System.Windows.Forms.Label()
        Me.lbl_kontakPacking = New System.Windows.Forms.Label()
        Me.lbl_atasNamaPacking = New System.Windows.Forms.Label()
        Me.lbl_jenisJualPacking = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.rtb_detailPenjualanPacking = New System.Windows.Forms.RichTextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.lbl_statusJualPacking = New System.Windows.Forms.Label()
        Me.lbl_metodeJualPacking = New System.Windows.Forms.Label()
        Me.lbl_totalJualPacking = New System.Windows.Forms.Label()
        Me.lbl_tglJualPacking = New System.Windows.Forms.Label()
        Me.lbl_noJualPacking = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pic_barcodePenjualanPickup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgv_detailPenjualanPickup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgv_listPenjualanPending, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.pnl_listDetail.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.dgv_penjualanPackingPickup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Window
        Me.Panel2.Controls.Add(Me.closeBtn)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(148, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1216, 69)
        Me.Panel2.TabIndex = 28
        '
        'closeBtn
        '
        Me.closeBtn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeBtn.ForeColor = System.Drawing.Color.Maroon
        Me.closeBtn.Location = New System.Drawing.Point(1157, 12)
        Me.closeBtn.Name = "closeBtn"
        Me.closeBtn.Size = New System.Drawing.Size(49, 30)
        Me.closeBtn.TabIndex = 22
        Me.closeBtn.Text = "| X |"
        Me.closeBtn.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Window
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label2.Location = New System.Drawing.Point(20, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 29)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Kasir"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Window
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel1.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(148, 749)
        Me.Panel1.TabIndex = 27
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(145, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(2, 768)
        Me.Label26.TabIndex = 23
        Me.Label26.Text = resources.GetString("Label26.Text")
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(13, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(122, 20)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Inventory System"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btnLogout, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 676)
        Me.TableLayoutPanel2.MinimumSize = New System.Drawing.Size(142, 73)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(148, 73)
        Me.TableLayoutPanel2.TabIndex = 22
        '
        'btnLogout
        '
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.Location = New System.Drawing.Point(3, 3)
        Me.btnLogout.MinimumSize = New System.Drawing.Size(142, 73)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(142, 73)
        Me.btnLogout.TabIndex = 27
        Me.btnLogout.Text = "🔙 Logout"
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnSemuaListPenjualan, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPickup, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.btnDelivery, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPOS_Kasir, 0, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 68)
        Me.TableLayoutPanel1.MaximumSize = New System.Drawing.Size(148, 280)
        Me.TableLayoutPanel1.MinimumSize = New System.Drawing.Size(148, 280)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(148, 280)
        Me.TableLayoutPanel1.TabIndex = 21
        '
        'btnSemuaListPenjualan
        '
        Me.btnSemuaListPenjualan.BackColor = System.Drawing.SystemColors.Window
        Me.btnSemuaListPenjualan.FlatAppearance.BorderSize = 0
        Me.btnSemuaListPenjualan.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSemuaListPenjualan.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnSemuaListPenjualan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSemuaListPenjualan.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSemuaListPenjualan.Location = New System.Drawing.Point(3, 213)
        Me.btnSemuaListPenjualan.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnSemuaListPenjualan.Name = "btnSemuaListPenjualan"
        Me.btnSemuaListPenjualan.Size = New System.Drawing.Size(142, 64)
        Me.btnSemuaListPenjualan.TabIndex = 27
        Me.btnSemuaListPenjualan.Text = "Barang Penjualan Bermasalah"
        Me.btnSemuaListPenjualan.UseVisualStyleBackColor = False
        '
        'btnPickup
        '
        Me.btnPickup.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPickup.FlatAppearance.BorderSize = 0
        Me.btnPickup.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPickup.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPickup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPickup.Location = New System.Drawing.Point(3, 143)
        Me.btnPickup.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnPickup.Name = "btnPickup"
        Me.btnPickup.Size = New System.Drawing.Size(142, 64)
        Me.btnPickup.TabIndex = 24
        Me.btnPickup.Text = "Pickup"
        Me.btnPickup.UseVisualStyleBackColor = False
        '
        'btnDelivery
        '
        Me.btnDelivery.BackColor = System.Drawing.SystemColors.Window
        Me.btnDelivery.FlatAppearance.BorderSize = 0
        Me.btnDelivery.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnDelivery.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnDelivery.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelivery.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelivery.Location = New System.Drawing.Point(3, 73)
        Me.btnDelivery.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnDelivery.Name = "btnDelivery"
        Me.btnDelivery.Size = New System.Drawing.Size(142, 64)
        Me.btnDelivery.TabIndex = 23
        Me.btnDelivery.Text = "Delivery"
        Me.btnDelivery.UseVisualStyleBackColor = False
        '
        'btnPOS_Kasir
        '
        Me.btnPOS_Kasir.BackColor = System.Drawing.SystemColors.Window
        Me.btnPOS_Kasir.FlatAppearance.BorderSize = 0
        Me.btnPOS_Kasir.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPOS_Kasir.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPOS_Kasir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPOS_Kasir.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPOS_Kasir.Location = New System.Drawing.Point(3, 3)
        Me.btnPOS_Kasir.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnPOS_Kasir.Name = "btnPOS_Kasir"
        Me.btnPOS_Kasir.Size = New System.Drawing.Size(142, 64)
        Me.btnPOS_Kasir.TabIndex = 22
        Me.btnPOS_Kasir.Text = "Penjualan (Sales) In-Person"
        Me.btnPOS_Kasir.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label1.Location = New System.Drawing.Point(13, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 43)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "P O S"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(148, 69)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(20, 10)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1216, 680)
        Me.TabControl1.TabIndex = 32
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.txtJenisDeliveryPickup)
        Me.TabPage1.Controls.Add(Me.cbo_statusPickup)
        Me.TabPage1.Controls.Add(Me.txt_noPenjualanPickup)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.dtp_tglJualPickup)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 41)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(1208, 635)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Penjualan PICKUP Baru"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnCancelPickup)
        Me.GroupBox1.Controls.Add(Me.pic_barcodePenjualanPickup)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.txt_kontakDeliveryPickup)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.txt_atasNamaDeliveryPickup)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Location = New System.Drawing.Point(27, 491)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(816, 145)
        Me.GroupBox1.TabIndex = 43
        Me.GroupBox1.TabStop = False
        '
        'btnCancelPickup
        '
        Me.btnCancelPickup.BackColor = System.Drawing.Color.FromArgb(CType(CType(218, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.btnCancelPickup.FlatAppearance.BorderSize = 0
        Me.btnCancelPickup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancelPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelPickup.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnCancelPickup.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCancelPickup.Location = New System.Drawing.Point(720, 41)
        Me.btnCancelPickup.Name = "btnCancelPickup"
        Me.btnCancelPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnCancelPickup.Size = New System.Drawing.Size(81, 84)
        Me.btnCancelPickup.TabIndex = 72
        Me.btnCancelPickup.Text = "Cancel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "🗑️"
        Me.btnCancelPickup.UseVisualStyleBackColor = False
        '
        'pic_barcodePenjualanPickup
        '
        Me.pic_barcodePenjualanPickup.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pic_barcodePenjualanPickup.BackColor = System.Drawing.SystemColors.Window
        Me.pic_barcodePenjualanPickup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pic_barcodePenjualanPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_barcodePenjualanPickup.Location = New System.Drawing.Point(226, 41)
        Me.pic_barcodePenjualanPickup.Name = "pic_barcodePenjualanPickup"
        Me.pic_barcodePenjualanPickup.Size = New System.Drawing.Size(488, 84)
        Me.pic_barcodePenjualanPickup.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_barcodePenjualanPickup.TabIndex = 71
        Me.pic_barcodePenjualanPickup.TabStop = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(223, 22)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(118, 16)
        Me.Label34.TabIndex = 70
        Me.Label34.Text = "Barcode Penjualan:"
        '
        'txt_kontakDeliveryPickup
        '
        Me.txt_kontakDeliveryPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_kontakDeliveryPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_kontakDeliveryPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_kontakDeliveryPickup.Location = New System.Drawing.Point(16, 99)
        Me.txt_kontakDeliveryPickup.Name = "txt_kontakDeliveryPickup"
        Me.txt_kontakDeliveryPickup.Size = New System.Drawing.Size(196, 26)
        Me.txt_kontakDeliveryPickup.TabIndex = 67
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(13, 80)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(108, 16)
        Me.Label30.TabIndex = 66
        Me.Label30.Text = "Kontak Penerima:"
        '
        'txt_atasNamaDeliveryPickup
        '
        Me.txt_atasNamaDeliveryPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_atasNamaDeliveryPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_atasNamaDeliveryPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_atasNamaDeliveryPickup.Location = New System.Drawing.Point(16, 41)
        Me.txt_atasNamaDeliveryPickup.Name = "txt_atasNamaDeliveryPickup"
        Me.txt_atasNamaDeliveryPickup.Size = New System.Drawing.Size(196, 26)
        Me.txt_atasNamaDeliveryPickup.TabIndex = 65
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(13, 22)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(74, 16)
        Me.Label29.TabIndex = 64
        Me.Label29.Text = "Atas Nama:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(765, 31)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(40, 16)
        Me.Label31.TabIndex = 42
        Me.Label31.Text = "Jenis:"
        '
        'txtJenisDeliveryPickup
        '
        Me.txtJenisDeliveryPickup.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.txtJenisDeliveryPickup.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtJenisDeliveryPickup.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJenisDeliveryPickup.Location = New System.Drawing.Point(743, 31)
        Me.txtJenisDeliveryPickup.Name = "txtJenisDeliveryPickup"
        Me.txtJenisDeliveryPickup.ReadOnly = True
        Me.txtJenisDeliveryPickup.Size = New System.Drawing.Size(100, 16)
        Me.txtJenisDeliveryPickup.TabIndex = 41
        Me.txtJenisDeliveryPickup.Text = "Pickup"
        Me.txtJenisDeliveryPickup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbo_statusPickup
        '
        Me.cbo_statusPickup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_statusPickup.FormattingEnabled = True
        Me.cbo_statusPickup.Items.AddRange(New Object() {"Pending", "Packing", "Siap Pickup", "Selesai"})
        Me.cbo_statusPickup.Location = New System.Drawing.Point(563, 24)
        Me.cbo_statusPickup.Name = "cbo_statusPickup"
        Me.cbo_statusPickup.Size = New System.Drawing.Size(170, 26)
        Me.cbo_statusPickup.TabIndex = 64
        '
        'txt_noPenjualanPickup
        '
        Me.txt_noPenjualanPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_noPenjualanPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_noPenjualanPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_noPenjualanPickup.Location = New System.Drawing.Point(308, 25)
        Me.txt_noPenjualanPickup.Name = "txt_noPenjualanPickup"
        Me.txt_noPenjualanPickup.ReadOnly = True
        Me.txt_noPenjualanPickup.Size = New System.Drawing.Size(170, 26)
        Me.txt_noPenjualanPickup.TabIndex = 38
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(509, 29)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(48, 16)
        Me.Label33.TabIndex = 65
        Me.Label33.Text = "Status:"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Window
        Me.Panel3.Controls.Add(Me.txt_catatanPickup)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.lbl_totalQtyPickup)
        Me.Panel3.Controls.Add(Me.Label27)
        Me.Panel3.Controls.Add(Me.cbo_metodePembayaranPickup)
        Me.Panel3.Controls.Add(Me.btn_simpanPenjualanPickup)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.cbo_statusPenjualanPickup)
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Controls.Add(Me.lbl_subTotalPickup)
        Me.Panel3.Controls.Add(Me.Label11)
        Me.Panel3.Controls.Add(Me.lbl_hargaSatuanPickup)
        Me.Panel3.Controls.Add(Me.Label12)
        Me.Panel3.Controls.Add(Me.lbl_QtyPickup)
        Me.Panel3.Controls.Add(Me.lbl_grandTotalPickup)
        Me.Panel3.Controls.Add(Me.lbl_noPenjualanPickup)
        Me.Panel3.Controls.Add(Me.txt_danaDiterimaPickup)
        Me.Panel3.Controls.Add(Me.Label25)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.lbl_kembalianPickup)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(863, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(345, 635)
        Me.Panel3.TabIndex = 39
        '
        'txt_catatanPickup
        '
        Me.txt_catatanPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_catatanPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_catatanPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.txt_catatanPickup.Location = New System.Drawing.Point(143, 475)
        Me.txt_catatanPickup.Multiline = True
        Me.txt_catatanPickup.Name = "txt_catatanPickup"
        Me.txt_catatanPickup.Size = New System.Drawing.Size(180, 63)
        Me.txt_catatanPickup.TabIndex = 66
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label6.Location = New System.Drawing.Point(66, 479)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 16)
        Me.Label6.TabIndex = 65
        Me.Label6.Text = "Catatan:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_totalQtyPickup
        '
        Me.lbl_totalQtyPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_totalQtyPickup.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.lbl_totalQtyPickup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_totalQtyPickup.Location = New System.Drawing.Point(23, 88)
        Me.lbl_totalQtyPickup.Name = "lbl_totalQtyPickup"
        Me.lbl_totalQtyPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_totalQtyPickup.Size = New System.Drawing.Size(295, 17)
        Me.lbl_totalQtyPickup.TabIndex = 64
        Me.lbl_totalQtyPickup.Text = "Total Barang:"
        Me.lbl_totalQtyPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(12, 48)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(325, 2)
        Me.Label27.TabIndex = 24
        Me.Label27.Text = resources.GetString("Label27.Text")
        '
        'cbo_metodePembayaranPickup
        '
        Me.cbo_metodePembayaranPickup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_metodePembayaranPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.cbo_metodePembayaranPickup.FormattingEnabled = True
        Me.cbo_metodePembayaranPickup.Items.AddRange(New Object() {"Tunai", "Non-Tunai"})
        Me.cbo_metodePembayaranPickup.Location = New System.Drawing.Point(143, 378)
        Me.cbo_metodePembayaranPickup.Name = "cbo_metodePembayaranPickup"
        Me.cbo_metodePembayaranPickup.Size = New System.Drawing.Size(180, 26)
        Me.cbo_metodePembayaranPickup.TabIndex = 59
        '
        'btn_simpanPenjualanPickup
        '
        Me.btn_simpanPenjualanPickup.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_simpanPenjualanPickup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_simpanPenjualanPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_simpanPenjualanPickup.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_simpanPenjualanPickup.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_simpanPenjualanPickup.Location = New System.Drawing.Point(12, 599)
        Me.btn_simpanPenjualanPickup.Name = "btn_simpanPenjualanPickup"
        Me.btn_simpanPenjualanPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_simpanPenjualanPickup.Size = New System.Drawing.Size(325, 40)
        Me.btn_simpanPenjualanPickup.TabIndex = 58
        Me.btn_simpanPenjualanPickup.Text = "Konfirmasi 💸"
        Me.btn_simpanPenjualanPickup.UseVisualStyleBackColor = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label22.Location = New System.Drawing.Point(75, 433)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(48, 16)
        Me.Label22.TabIndex = 55
        Me.Label22.Text = "Status:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbo_statusPenjualanPickup
        '
        Me.cbo_statusPenjualanPickup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_statusPenjualanPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.cbo_statusPenjualanPickup.FormattingEnabled = True
        Me.cbo_statusPenjualanPickup.Items.AddRange(New Object() {"Lunas", "Pending"})
        Me.cbo_statusPenjualanPickup.Location = New System.Drawing.Point(143, 428)
        Me.cbo_statusPenjualanPickup.Name = "cbo_statusPenjualanPickup"
        Me.cbo_statusPenjualanPickup.Size = New System.Drawing.Size(180, 26)
        Me.cbo_statusPenjualanPickup.TabIndex = 52
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label21.Location = New System.Drawing.Point(37, 383)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(83, 16)
        Me.Label21.TabIndex = 53
        Me.Label21.Text = "Pembayaran:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(84, 238)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(41, 16)
        Me.Label19.TabIndex = 8
        Me.Label19.Text = "Total:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_subTotalPickup
        '
        Me.lbl_subTotalPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_subTotalPickup.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_subTotalPickup.ForeColor = System.Drawing.Color.Firebrick
        Me.lbl_subTotalPickup.Location = New System.Drawing.Point(143, 219)
        Me.lbl_subTotalPickup.Name = "lbl_subTotalPickup"
        Me.lbl_subTotalPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_subTotalPickup.Size = New System.Drawing.Size(180, 27)
        Me.lbl_subTotalPickup.TabIndex = 7
        Me.lbl_subTotalPickup.Text = "00.00"
        Me.lbl_subTotalPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(31, 191)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 16)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Harga Satuan:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_hargaSatuanPickup
        '
        Me.lbl_hargaSatuanPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_hargaSatuanPickup.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_hargaSatuanPickup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_hargaSatuanPickup.Location = New System.Drawing.Point(143, 172)
        Me.lbl_hargaSatuanPickup.Name = "lbl_hargaSatuanPickup"
        Me.lbl_hargaSatuanPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_hargaSatuanPickup.Size = New System.Drawing.Size(180, 27)
        Me.lbl_hargaSatuanPickup.TabIndex = 5
        Me.lbl_hargaSatuanPickup.Text = "00.00"
        Me.lbl_hargaSatuanPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(44, 146)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 16)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Qty Barang:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_QtyPickup
        '
        Me.lbl_QtyPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_QtyPickup.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_QtyPickup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_QtyPickup.Location = New System.Drawing.Point(143, 135)
        Me.lbl_QtyPickup.Name = "lbl_QtyPickup"
        Me.lbl_QtyPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_QtyPickup.Size = New System.Drawing.Size(180, 27)
        Me.lbl_QtyPickup.TabIndex = 3
        Me.lbl_QtyPickup.Text = "00"
        Me.lbl_QtyPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_grandTotalPickup
        '
        Me.lbl_grandTotalPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_grandTotalPickup.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_grandTotalPickup.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lbl_grandTotalPickup.Location = New System.Drawing.Point(23, 52)
        Me.lbl_grandTotalPickup.Name = "lbl_grandTotalPickup"
        Me.lbl_grandTotalPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_grandTotalPickup.Size = New System.Drawing.Size(300, 33)
        Me.lbl_grandTotalPickup.TabIndex = 1
        Me.lbl_grandTotalPickup.Text = "00.00"
        Me.lbl_grandTotalPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_noPenjualanPickup
        '
        Me.lbl_noPenjualanPickup.BackColor = System.Drawing.Color.Transparent
        Me.lbl_noPenjualanPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_noPenjualanPickup.Location = New System.Drawing.Point(3, 15)
        Me.lbl_noPenjualanPickup.Name = "lbl_noPenjualanPickup"
        Me.lbl_noPenjualanPickup.Size = New System.Drawing.Size(339, 25)
        Me.lbl_noPenjualanPickup.TabIndex = 0
        Me.lbl_noPenjualanPickup.Text = "-"
        Me.lbl_noPenjualanPickup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_danaDiterimaPickup
        '
        Me.txt_danaDiterimaPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_danaDiterimaPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_danaDiterimaPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.txt_danaDiterimaPickup.Location = New System.Drawing.Point(143, 281)
        Me.txt_danaDiterimaPickup.Name = "txt_danaDiterimaPickup"
        Me.txt_danaDiterimaPickup.Size = New System.Drawing.Size(180, 25)
        Me.txt_danaDiterimaPickup.TabIndex = 61
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label25.Location = New System.Drawing.Point(28, 285)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(93, 16)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Dana Diterima:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(53, 339)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(71, 16)
        Me.Label23.TabIndex = 57
        Me.Label23.Text = "Kembalian:"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_kembalianPickup
        '
        Me.lbl_kembalianPickup.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lbl_kembalianPickup.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_kembalianPickup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_kembalianPickup.Location = New System.Drawing.Point(143, 320)
        Me.lbl_kembalianPickup.Name = "lbl_kembalianPickup"
        Me.lbl_kembalianPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_kembalianPickup.Size = New System.Drawing.Size(180, 27)
        Me.lbl_kembalianPickup.TabIndex = 56
        Me.lbl_kembalianPickup.Text = "00.00"
        Me.lbl_kembalianPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lst_pickupResult)
        Me.GroupBox2.Controls.Add(Me.txt_pickupSearchBrng)
        Me.GroupBox2.Controls.Add(Me.Label85)
        Me.GroupBox2.Controls.Add(Me.txt_satuanBrgPickup)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.txt_namaBrgPickup)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.cbo_brgPickup)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.txt_subTotalPickup)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txt_hrgaPickup)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txt_qtyPickup)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.btn_tmbhDetBeliPickup)
        Me.GroupBox2.Controls.Add(Me.dgv_detailPenjualanPickup)
        Me.GroupBox2.Location = New System.Drawing.Point(27, 63)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(816, 418)
        Me.GroupBox2.TabIndex = 38
        Me.GroupBox2.TabStop = False
        '
        'lst_pickupResult
        '
        Me.lst_pickupResult.FormattingEnabled = True
        Me.lst_pickupResult.ItemHeight = 18
        Me.lst_pickupResult.Location = New System.Drawing.Point(16, 62)
        Me.lst_pickupResult.Name = "lst_pickupResult"
        Me.lst_pickupResult.Size = New System.Drawing.Size(778, 40)
        Me.lst_pickupResult.TabIndex = 76
        Me.lst_pickupResult.Visible = False
        '
        'txt_pickupSearchBrng
        '
        Me.txt_pickupSearchBrng.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_pickupSearchBrng.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_pickupSearchBrng.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_pickupSearchBrng.Location = New System.Drawing.Point(16, 37)
        Me.txt_pickupSearchBrng.Name = "txt_pickupSearchBrng"
        Me.txt_pickupSearchBrng.Size = New System.Drawing.Size(778, 26)
        Me.txt_pickupSearchBrng.TabIndex = 73
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(13, 18)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(52, 16)
        Me.Label85.TabIndex = 72
        Me.Label85.Text = "Barang:"
        '
        'txt_satuanBrgPickup
        '
        Me.txt_satuanBrgPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_satuanBrgPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_satuanBrgPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_satuanBrgPickup.Location = New System.Drawing.Point(116, 207)
        Me.txt_satuanBrgPickup.Name = "txt_satuanBrgPickup"
        Me.txt_satuanBrgPickup.ReadOnly = True
        Me.txt_satuanBrgPickup.Size = New System.Drawing.Size(96, 26)
        Me.txt_satuanBrgPickup.TabIndex = 63
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(519, 76)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(275, 16)
        Me.Label18.TabIndex = 62
        Me.Label18.Text = "*Double klik barang jika ingin hapus barang itu"
        '
        'txt_namaBrgPickup
        '
        Me.txt_namaBrgPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_namaBrgPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_namaBrgPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_namaBrgPickup.Location = New System.Drawing.Point(16, 152)
        Me.txt_namaBrgPickup.Name = "txt_namaBrgPickup"
        Me.txt_namaBrgPickup.ReadOnly = True
        Me.txt_namaBrgPickup.Size = New System.Drawing.Size(196, 26)
        Me.txt_namaBrgPickup.TabIndex = 61
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(13, 133)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(89, 16)
        Me.Label16.TabIndex = 60
        Me.Label16.Text = "Nama Barang:"
        '
        'cbo_brgPickup
        '
        Me.cbo_brgPickup.FormattingEnabled = True
        Me.cbo_brgPickup.Location = New System.Drawing.Point(16, 95)
        Me.cbo_brgPickup.Name = "cbo_brgPickup"
        Me.cbo_brgPickup.Size = New System.Drawing.Size(196, 26)
        Me.cbo_brgPickup.TabIndex = 37
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(113, 188)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(52, 16)
        Me.Label15.TabIndex = 59
        Me.Label15.Text = "Satuan:"
        '
        'txt_subTotalPickup
        '
        Me.txt_subTotalPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_subTotalPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_subTotalPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_subTotalPickup.Location = New System.Drawing.Point(16, 320)
        Me.txt_subTotalPickup.Name = "txt_subTotalPickup"
        Me.txt_subTotalPickup.ReadOnly = True
        Me.txt_subTotalPickup.Size = New System.Drawing.Size(196, 26)
        Me.txt_subTotalPickup.TabIndex = 58
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(13, 301)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 16)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "Subtotal:"
        '
        'txt_hrgaPickup
        '
        Me.txt_hrgaPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_hrgaPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_hrgaPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_hrgaPickup.Location = New System.Drawing.Point(16, 265)
        Me.txt_hrgaPickup.Name = "txt_hrgaPickup"
        Me.txt_hrgaPickup.ReadOnly = True
        Me.txt_hrgaPickup.Size = New System.Drawing.Size(196, 26)
        Me.txt_hrgaPickup.TabIndex = 56
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 246)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 16)
        Me.Label9.TabIndex = 55
        Me.Label9.Text = "Harga per Satuan:"
        '
        'txt_qtyPickup
        '
        Me.txt_qtyPickup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_qtyPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_qtyPickup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_qtyPickup.Location = New System.Drawing.Point(16, 207)
        Me.txt_qtyPickup.Name = "txt_qtyPickup"
        Me.txt_qtyPickup.Size = New System.Drawing.Size(96, 26)
        Me.txt_qtyPickup.TabIndex = 54
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(13, 188)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 16)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "Qty:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(13, 76)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 16)
        Me.Label7.TabIndex = 51
        Me.Label7.Text = "Kode Barang:"
        '
        'btn_tmbhDetBeliPickup
        '
        Me.btn_tmbhDetBeliPickup.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_tmbhDetBeliPickup.FlatAppearance.BorderSize = 0
        Me.btn_tmbhDetBeliPickup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tmbhDetBeliPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.btn_tmbhDetBeliPickup.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_tmbhDetBeliPickup.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhDetBeliPickup.Location = New System.Drawing.Point(16, 372)
        Me.btn_tmbhDetBeliPickup.Name = "btn_tmbhDetBeliPickup"
        Me.btn_tmbhDetBeliPickup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_tmbhDetBeliPickup.Size = New System.Drawing.Size(196, 29)
        Me.btn_tmbhDetBeliPickup.TabIndex = 50
        Me.btn_tmbhDetBeliPickup.Text = "➕ Tambah Barang"
        Me.btn_tmbhDetBeliPickup.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhDetBeliPickup.UseVisualStyleBackColor = False
        '
        'dgv_detailPenjualanPickup
        '
        Me.dgv_detailPenjualanPickup.AllowUserToAddRows = False
        Me.dgv_detailPenjualanPickup.AllowUserToDeleteRows = False
        Me.dgv_detailPenjualanPickup.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_detailPenjualanPickup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_detailPenjualanPickup.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNo, Me.colKodeBrg, Me.colNmaBrg, Me.colQty, Me.colSatuan, Me.colHarga, Me.colSubtotal, Me.colBarcodePickup})
        Me.dgv_detailPenjualanPickup.Location = New System.Drawing.Point(226, 95)
        Me.dgv_detailPenjualanPickup.Name = "dgv_detailPenjualanPickup"
        Me.dgv_detailPenjualanPickup.ReadOnly = True
        Me.dgv_detailPenjualanPickup.RowHeadersVisible = False
        Me.dgv_detailPenjualanPickup.Size = New System.Drawing.Size(568, 306)
        Me.dgv_detailPenjualanPickup.TabIndex = 0
        '
        'colNo
        '
        Me.colNo.HeaderText = "#"
        Me.colNo.Name = "colNo"
        Me.colNo.ReadOnly = True
        Me.colNo.Width = 40
        '
        'colKodeBrg
        '
        Me.colKodeBrg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKodeBrg.HeaderText = "Kode"
        Me.colKodeBrg.Name = "colKodeBrg"
        Me.colKodeBrg.ReadOnly = True
        Me.colKodeBrg.Width = 66
        '
        'colNmaBrg
        '
        Me.colNmaBrg.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNmaBrg.HeaderText = "Nama"
        Me.colNmaBrg.Name = "colNmaBrg"
        Me.colNmaBrg.ReadOnly = True
        Me.colNmaBrg.Width = 72
        '
        'colQty
        '
        Me.colQty.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colQty.HeaderText = "Qty"
        Me.colQty.Name = "colQty"
        Me.colQty.ReadOnly = True
        Me.colQty.Width = 57
        '
        'colSatuan
        '
        Me.colSatuan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSatuan.HeaderText = "Satuan"
        Me.colSatuan.Name = "colSatuan"
        Me.colSatuan.ReadOnly = True
        Me.colSatuan.Width = 78
        '
        'colHarga
        '
        Me.colHarga.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colHarga.HeaderText = "Harga"
        Me.colHarga.Name = "colHarga"
        Me.colHarga.ReadOnly = True
        Me.colHarga.Width = 72
        '
        'colSubtotal
        '
        Me.colSubtotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSubtotal.HeaderText = "Subtotal"
        Me.colSubtotal.Name = "colSubtotal"
        Me.colSubtotal.ReadOnly = True
        Me.colSubtotal.Width = 85
        '
        'colBarcodePickup
        '
        Me.colBarcodePickup.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBarcodePickup.HeaderText = "Barcode"
        Me.colBarcodePickup.Name = "colBarcodePickup"
        Me.colBarcodePickup.ReadOnly = True
        Me.colBarcodePickup.Width = 86
        '
        'dtp_tglJualPickup
        '
        Me.dtp_tglJualPickup.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.dtp_tglJualPickup.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_tglJualPickup.Location = New System.Drawing.Point(69, 25)
        Me.dtp_tglJualPickup.Name = "dtp_tglJualPickup"
        Me.dtp_tglJualPickup.Size = New System.Drawing.Size(170, 25)
        Me.dtp_tglJualPickup.TabIndex = 32
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(34, 29)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 16)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Tgl."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(276, 29)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(26, 16)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "No."
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dgv_listPenjualanPending)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.Panel5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 41)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1208, 635)
        Me.TabPage2.TabIndex = 4
        Me.TabPage2.Text = "Pembayaran Pending"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dgv_listPenjualanPending
        '
        Me.dgv_listPenjualanPending.AllowUserToAddRows = False
        Me.dgv_listPenjualanPending.AllowUserToDeleteRows = False
        Me.dgv_listPenjualanPending.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgv_listPenjualanPending.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_listPenjualanPending.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv_listPenjualanPending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_listPenjualanPending.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNmr, Me.colNoPenjualan, Me.colJenis, Me.colTglPembelian, Me.colTotalPenjualan, Me.colDanaDiterima, Me.colKembalian, Me.colMetodePembayaran, Me.colCatatan, Me.colAtasN, Me.colKontak, Me.colStatusPKirim})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_listPenjualanPending.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgv_listPenjualanPending.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_listPenjualanPending.Location = New System.Drawing.Point(3, 53)
        Me.dgv_listPenjualanPending.Name = "dgv_listPenjualanPending"
        Me.dgv_listPenjualanPending.ReadOnly = True
        Me.dgv_listPenjualanPending.RowHeadersVisible = False
        Me.dgv_listPenjualanPending.Size = New System.Drawing.Size(810, 579)
        Me.dgv_listPenjualanPending.TabIndex = 21
        '
        'colNmr
        '
        Me.colNmr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNmr.HeaderText = "#"
        Me.colNmr.MinimumWidth = 44
        Me.colNmr.Name = "colNmr"
        Me.colNmr.ReadOnly = True
        Me.colNmr.Width = 44
        '
        'colNoPenjualan
        '
        Me.colNoPenjualan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoPenjualan.HeaderText = "No. Penjualan"
        Me.colNoPenjualan.MinimumWidth = 154
        Me.colNoPenjualan.Name = "colNoPenjualan"
        Me.colNoPenjualan.ReadOnly = True
        Me.colNoPenjualan.Width = 154
        '
        'colJenis
        '
        Me.colJenis.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colJenis.HeaderText = "Jenis"
        Me.colJenis.Name = "colJenis"
        Me.colJenis.ReadOnly = True
        Me.colJenis.Visible = False
        '
        'colTglPembelian
        '
        Me.colTglPembelian.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTglPembelian.HeaderText = "Tgl"
        Me.colTglPembelian.MinimumWidth = 85
        Me.colTglPembelian.Name = "colTglPembelian"
        Me.colTglPembelian.ReadOnly = True
        Me.colTglPembelian.Width = 85
        '
        'colTotalPenjualan
        '
        Me.colTotalPenjualan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colTotalPenjualan.HeaderText = "Total"
        Me.colTotalPenjualan.MinimumWidth = 105
        Me.colTotalPenjualan.Name = "colTotalPenjualan"
        Me.colTotalPenjualan.ReadOnly = True
        '
        'colDanaDiterima
        '
        Me.colDanaDiterima.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDanaDiterima.HeaderText = "Dana Diterima"
        Me.colDanaDiterima.Name = "colDanaDiterima"
        Me.colDanaDiterima.ReadOnly = True
        Me.colDanaDiterima.Visible = False
        '
        'colKembalian
        '
        Me.colKembalian.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKembalian.HeaderText = "Kembalian"
        Me.colKembalian.Name = "colKembalian"
        Me.colKembalian.ReadOnly = True
        Me.colKembalian.Visible = False
        '
        'colMetodePembayaran
        '
        Me.colMetodePembayaran.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMetodePembayaran.HeaderText = "Metode"
        Me.colMetodePembayaran.Name = "colMetodePembayaran"
        Me.colMetodePembayaran.ReadOnly = True
        Me.colMetodePembayaran.Width = 82
        '
        'colCatatan
        '
        Me.colCatatan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCatatan.HeaderText = "Catatan"
        Me.colCatatan.Name = "colCatatan"
        Me.colCatatan.ReadOnly = True
        Me.colCatatan.Width = 84
        '
        'colAtasN
        '
        Me.colAtasN.HeaderText = "Atas Nama"
        Me.colAtasN.Name = "colAtasN"
        Me.colAtasN.ReadOnly = True
        '
        'colKontak
        '
        Me.colKontak.HeaderText = "Kontak"
        Me.colKontak.Name = "colKontak"
        Me.colKontak.ReadOnly = True
        '
        'colStatusPKirim
        '
        Me.colStatusPKirim.HeaderText = "Status Kirim"
        Me.colStatusPKirim.Name = "colStatusPKirim"
        Me.colStatusPKirim.ReadOnly = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.txt_cariPenjualan)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(810, 50)
        Me.Panel4.TabIndex = 22
        '
        'txt_cariPenjualan
        '
        Me.txt_cariPenjualan.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_cariPenjualan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_cariPenjualan.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_cariPenjualan.Location = New System.Drawing.Point(136, 12)
        Me.txt_cariPenjualan.Name = "txt_cariPenjualan"
        Me.txt_cariPenjualan.Size = New System.Drawing.Size(240, 26)
        Me.txt_cariPenjualan.TabIndex = 26
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 16)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Search Penjualan:"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.Window
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.lbl_catatanPending)
        Me.Panel5.Controls.Add(Me.lbl_statusKirimPending)
        Me.Panel5.Controls.Add(Me.lbl_kontakPending)
        Me.Panel5.Controls.Add(Me.lbl_atasNamaPending)
        Me.Panel5.Controls.Add(Me.lbl_jenisJualPending)
        Me.Panel5.Controls.Add(Me.pnl_listDetail)
        Me.Panel5.Controls.Add(Me.lbl_statusJualPending)
        Me.Panel5.Controls.Add(Me.lbl_metodeJualPending)
        Me.Panel5.Controls.Add(Me.lbl_totalJualPending)
        Me.Panel5.Controls.Add(Me.lbl_tglJualPending)
        Me.Panel5.Controls.Add(Me.lbl_noJualPending)
        Me.Panel5.Controls.Add(Me.Label24)
        Me.Panel5.Controls.Add(Me.Label28)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel5.Location = New System.Drawing.Point(813, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(392, 629)
        Me.Panel5.TabIndex = 23
        '
        'lbl_catatanPending
        '
        Me.lbl_catatanPending.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_catatanPending.Location = New System.Drawing.Point(13, 189)
        Me.lbl_catatanPending.Name = "lbl_catatanPending"
        Me.lbl_catatanPending.Size = New System.Drawing.Size(179, 60)
        Me.lbl_catatanPending.TabIndex = 48
        Me.lbl_catatanPending.Text = ""
        '
        'lbl_statusKirimPending
        '
        Me.lbl_statusKirimPending.AutoSize = True
        Me.lbl_statusKirimPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statusKirimPending.Location = New System.Drawing.Point(207, 128)
        Me.lbl_statusKirimPending.Name = "lbl_statusKirimPending"
        Me.lbl_statusKirimPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_statusKirimPending.TabIndex = 47
        Me.lbl_statusKirimPending.Text = "-"
        '
        'lbl_kontakPending
        '
        Me.lbl_kontakPending.AutoSize = True
        Me.lbl_kontakPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_kontakPending.Location = New System.Drawing.Point(207, 98)
        Me.lbl_kontakPending.Name = "lbl_kontakPending"
        Me.lbl_kontakPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_kontakPending.TabIndex = 46
        Me.lbl_kontakPending.Text = "-"
        '
        'lbl_atasNamaPending
        '
        Me.lbl_atasNamaPending.AutoSize = True
        Me.lbl_atasNamaPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_atasNamaPending.Location = New System.Drawing.Point(207, 68)
        Me.lbl_atasNamaPending.Name = "lbl_atasNamaPending"
        Me.lbl_atasNamaPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_atasNamaPending.TabIndex = 45
        Me.lbl_atasNamaPending.Text = "-"
        '
        'lbl_jenisJualPending
        '
        Me.lbl_jenisJualPending.AutoSize = True
        Me.lbl_jenisJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_jenisJualPending.Location = New System.Drawing.Point(207, 158)
        Me.lbl_jenisJualPending.Name = "lbl_jenisJualPending"
        Me.lbl_jenisJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_jenisJualPending.TabIndex = 39
        Me.lbl_jenisJualPending.Text = "-"
        '
        'pnl_listDetail
        '
        Me.pnl_listDetail.Controls.Add(Me.Label13)
        Me.pnl_listDetail.Controls.Add(Me.rtb_detailPenjualan)
        Me.pnl_listDetail.Controls.Add(Me.Label14)
        Me.pnl_listDetail.Controls.Add(Me.Label20)
        Me.pnl_listDetail.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnl_listDetail.Location = New System.Drawing.Point(0, 241)
        Me.pnl_listDetail.Name = "pnl_listDetail"
        Me.pnl_listDetail.Size = New System.Drawing.Size(390, 339)
        Me.pnl_listDetail.TabIndex = 21
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(0, 1)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(390, 1)
        Me.Label13.TabIndex = 33
        Me.Label13.Text = resources.GetString("Label13.Text")
        '
        'rtb_detailPenjualan
        '
        Me.rtb_detailPenjualan.BackColor = System.Drawing.SystemColors.Window
        Me.rtb_detailPenjualan.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb_detailPenjualan.Location = New System.Drawing.Point(14, 41)
        Me.rtb_detailPenjualan.Name = "rtb_detailPenjualan"
        Me.rtb_detailPenjualan.ReadOnly = True
        Me.rtb_detailPenjualan.Size = New System.Drawing.Size(362, 270)
        Me.rtb_detailPenjualan.TabIndex = 32
        Me.rtb_detailPenjualan.Text = ""
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label14.Location = New System.Drawing.Point(131, 7)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(142, 18)
        Me.Label14.TabIndex = 30
        Me.Label14.Text = "Detail List Barang"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(0, 30)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(390, 1)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = resources.GetString("Label20.Text")
        '
        'lbl_statusJualPending
        '
        Me.lbl_statusJualPending.AutoSize = True
        Me.lbl_statusJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statusJualPending.Location = New System.Drawing.Point(11, 158)
        Me.lbl_statusJualPending.Name = "lbl_statusJualPending"
        Me.lbl_statusJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_statusJualPending.TabIndex = 31
        Me.lbl_statusJualPending.Text = "-"
        '
        'lbl_metodeJualPending
        '
        Me.lbl_metodeJualPending.AutoSize = True
        Me.lbl_metodeJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_metodeJualPending.Location = New System.Drawing.Point(11, 128)
        Me.lbl_metodeJualPending.Name = "lbl_metodeJualPending"
        Me.lbl_metodeJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_metodeJualPending.TabIndex = 30
        Me.lbl_metodeJualPending.Text = "-"
        '
        'lbl_totalJualPending
        '
        Me.lbl_totalJualPending.AutoSize = True
        Me.lbl_totalJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_totalJualPending.Location = New System.Drawing.Point(11, 98)
        Me.lbl_totalJualPending.Name = "lbl_totalJualPending"
        Me.lbl_totalJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_totalJualPending.TabIndex = 29
        Me.lbl_totalJualPending.Text = "-"
        '
        'lbl_tglJualPending
        '
        Me.lbl_tglJualPending.AutoSize = True
        Me.lbl_tglJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tglJualPending.Location = New System.Drawing.Point(11, 68)
        Me.lbl_tglJualPending.Name = "lbl_tglJualPending"
        Me.lbl_tglJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_tglJualPending.TabIndex = 28
        Me.lbl_tglJualPending.Text = "-"
        '
        'lbl_noJualPending
        '
        Me.lbl_noJualPending.AutoSize = True
        Me.lbl_noJualPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_noJualPending.Location = New System.Drawing.Point(11, 38)
        Me.lbl_noJualPending.Name = "lbl_noJualPending"
        Me.lbl_noJualPending.Size = New System.Drawing.Size(13, 18)
        Me.lbl_noJualPending.TabIndex = 27
        Me.lbl_noJualPending.Text = "-"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label24.Location = New System.Drawing.Point(-1, 3)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(392, 18)
        Me.Label24.TabIndex = 26
        Me.Label24.Text = "Informasi Penjualan"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(0, 26)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(390, 1)
        Me.Label28.TabIndex = 25
        Me.Label28.Text = resources.GetString("Label28.Text")
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btn_clearPenjualanPending)
        Me.Panel6.Controls.Add(Me.btn_updateLunasPenjualan)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel6.Location = New System.Drawing.Point(0, 580)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(390, 47)
        Me.Panel6.TabIndex = 35
        '
        'btn_clearPenjualanPending
        '
        Me.btn_clearPenjualanPending.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_clearPenjualanPending.FlatAppearance.BorderSize = 0
        Me.btn_clearPenjualanPending.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_clearPenjualanPending.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_clearPenjualanPending.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_clearPenjualanPending.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_clearPenjualanPending.Location = New System.Drawing.Point(200, 9)
        Me.btn_clearPenjualanPending.Name = "btn_clearPenjualanPending"
        Me.btn_clearPenjualanPending.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_clearPenjualanPending.Size = New System.Drawing.Size(180, 29)
        Me.btn_clearPenjualanPending.TabIndex = 49
        Me.btn_clearPenjualanPending.Text = "Clear 🧹"
        Me.btn_clearPenjualanPending.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_clearPenjualanPending.UseVisualStyleBackColor = False
        '
        'btn_updateLunasPenjualan
        '
        Me.btn_updateLunasPenjualan.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(56, Byte), Integer))
        Me.btn_updateLunasPenjualan.FlatAppearance.BorderSize = 0
        Me.btn_updateLunasPenjualan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_updateLunasPenjualan.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updateLunasPenjualan.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_updateLunasPenjualan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateLunasPenjualan.Location = New System.Drawing.Point(12, 9)
        Me.btn_updateLunasPenjualan.Name = "btn_updateLunasPenjualan"
        Me.btn_updateLunasPenjualan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_updateLunasPenjualan.Size = New System.Drawing.Size(180, 29)
        Me.btn_updateLunasPenjualan.TabIndex = 48
        Me.btn_updateLunasPenjualan.Text = "Update Sudah Lunas ✏️"
        Me.btn_updateLunasPenjualan.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateLunasPenjualan.UseVisualStyleBackColor = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.dgv_penjualanPackingPickup)
        Me.TabPage3.Controls.Add(Me.Panel7)
        Me.TabPage3.Controls.Add(Me.Panel8)
        Me.TabPage3.Location = New System.Drawing.Point(4, 41)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1208, 635)
        Me.TabPage3.TabIndex = 5
        Me.TabPage3.Text = "Masih Dipacking"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'dgv_penjualanPackingPickup
        '
        Me.dgv_penjualanPackingPickup.AllowUserToAddRows = False
        Me.dgv_penjualanPackingPickup.AllowUserToDeleteRows = False
        Me.dgv_penjualanPackingPickup.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgv_penjualanPackingPickup.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_penjualanPackingPickup.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv_penjualanPackingPickup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_penjualanPackingPickup.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.colNoPenjualanPickupPacking, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_penjualanPackingPickup.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgv_penjualanPackingPickup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_penjualanPackingPickup.Location = New System.Drawing.Point(3, 53)
        Me.dgv_penjualanPackingPickup.Name = "dgv_penjualanPackingPickup"
        Me.dgv_penjualanPackingPickup.ReadOnly = True
        Me.dgv_penjualanPackingPickup.RowHeadersVisible = False
        Me.dgv_penjualanPackingPickup.Size = New System.Drawing.Size(810, 579)
        Me.dgv_penjualanPackingPickup.TabIndex = 24
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn1.HeaderText = "#"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 44
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 44
        '
        'colNoPenjualanPickupPacking
        '
        Me.colNoPenjualanPickupPacking.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoPenjualanPickupPacking.HeaderText = "No. Penjualan"
        Me.colNoPenjualanPickupPacking.MinimumWidth = 154
        Me.colNoPenjualanPickupPacking.Name = "colNoPenjualanPickupPacking"
        Me.colNoPenjualanPickupPacking.ReadOnly = True
        Me.colNoPenjualanPickupPacking.Width = 154
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn3.HeaderText = "Jenis"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Visible = False
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn4.HeaderText = "Tgl"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 85
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 85
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn5.HeaderText = "Total"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 105
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn6.HeaderText = "Dana Diterima"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Visible = False
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn7.HeaderText = "Kembalian"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Visible = False
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn8.HeaderText = "Metode"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 82
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn9.HeaderText = "Catatan"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 84
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Atas Nama"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Kontak"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Status Kirim"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.txtCariPenjualanPacking)
        Me.Panel7.Controls.Add(Me.Label32)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel7.Location = New System.Drawing.Point(3, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(810, 50)
        Me.Panel7.TabIndex = 25
        '
        'txtCariPenjualanPacking
        '
        Me.txtCariPenjualanPacking.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtCariPenjualanPacking.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCariPenjualanPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCariPenjualanPacking.Location = New System.Drawing.Point(136, 12)
        Me.txtCariPenjualanPacking.Name = "txtCariPenjualanPacking"
        Me.txtCariPenjualanPacking.Size = New System.Drawing.Size(240, 26)
        Me.txtCariPenjualanPacking.TabIndex = 26
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(15, 16)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(112, 16)
        Me.Label32.TabIndex = 25
        Me.Label32.Text = "Search Penjualan:"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.Window
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.lbl_catatanPacking)
        Me.Panel8.Controls.Add(Me.lbl_statusKirimPacking)
        Me.Panel8.Controls.Add(Me.lbl_kontakPacking)
        Me.Panel8.Controls.Add(Me.lbl_atasNamaPacking)
        Me.Panel8.Controls.Add(Me.lbl_jenisJualPacking)
        Me.Panel8.Controls.Add(Me.Panel9)
        Me.Panel8.Controls.Add(Me.lbl_statusJualPacking)
        Me.Panel8.Controls.Add(Me.lbl_metodeJualPacking)
        Me.Panel8.Controls.Add(Me.lbl_totalJualPacking)
        Me.Panel8.Controls.Add(Me.lbl_tglJualPacking)
        Me.Panel8.Controls.Add(Me.lbl_noJualPacking)
        Me.Panel8.Controls.Add(Me.Label48)
        Me.Panel8.Controls.Add(Me.Label49)
        Me.Panel8.Controls.Add(Me.Panel10)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel8.Location = New System.Drawing.Point(813, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(392, 629)
        Me.Panel8.TabIndex = 26
        '
        'lbl_catatanPacking
        '
        Me.lbl_catatanPacking.BackColor = System.Drawing.SystemColors.Window
        Me.lbl_catatanPacking.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_catatanPacking.Location = New System.Drawing.Point(13, 189)
        Me.lbl_catatanPacking.Name = "lbl_catatanPacking"
        Me.lbl_catatanPacking.ReadOnly = True
        Me.lbl_catatanPacking.Size = New System.Drawing.Size(179, 60)
        Me.lbl_catatanPacking.TabIndex = 48
        Me.lbl_catatanPacking.Text = ""
        '
        'lbl_statusKirimPacking
        '
        Me.lbl_statusKirimPacking.AutoSize = True
        Me.lbl_statusKirimPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statusKirimPacking.Location = New System.Drawing.Point(208, 128)
        Me.lbl_statusKirimPacking.Name = "lbl_statusKirimPacking"
        Me.lbl_statusKirimPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_statusKirimPacking.TabIndex = 47
        Me.lbl_statusKirimPacking.Text = "-"
        '
        'lbl_kontakPacking
        '
        Me.lbl_kontakPacking.AutoSize = True
        Me.lbl_kontakPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_kontakPacking.Location = New System.Drawing.Point(208, 98)
        Me.lbl_kontakPacking.Name = "lbl_kontakPacking"
        Me.lbl_kontakPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_kontakPacking.TabIndex = 46
        Me.lbl_kontakPacking.Text = "-"
        '
        'lbl_atasNamaPacking
        '
        Me.lbl_atasNamaPacking.AutoSize = True
        Me.lbl_atasNamaPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_atasNamaPacking.Location = New System.Drawing.Point(208, 68)
        Me.lbl_atasNamaPacking.Name = "lbl_atasNamaPacking"
        Me.lbl_atasNamaPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_atasNamaPacking.TabIndex = 45
        Me.lbl_atasNamaPacking.Text = "-"
        '
        'lbl_jenisJualPacking
        '
        Me.lbl_jenisJualPacking.AutoSize = True
        Me.lbl_jenisJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_jenisJualPacking.Location = New System.Drawing.Point(208, 158)
        Me.lbl_jenisJualPacking.Name = "lbl_jenisJualPacking"
        Me.lbl_jenisJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_jenisJualPacking.TabIndex = 39
        Me.lbl_jenisJualPacking.Text = "-"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Label40)
        Me.Panel9.Controls.Add(Me.rtb_detailPenjualanPacking)
        Me.Panel9.Controls.Add(Me.Label41)
        Me.Panel9.Controls.Add(Me.Label42)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(0, 241)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(390, 339)
        Me.Panel9.TabIndex = 21
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label40.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(0, 1)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(390, 1)
        Me.Label40.TabIndex = 33
        Me.Label40.Text = resources.GetString("Label40.Text")
        '
        'rtb_detailPenjualanPacking
        '
        Me.rtb_detailPenjualanPacking.BackColor = System.Drawing.SystemColors.Window
        Me.rtb_detailPenjualanPacking.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtb_detailPenjualanPacking.Location = New System.Drawing.Point(14, 41)
        Me.rtb_detailPenjualanPacking.Name = "rtb_detailPenjualanPacking"
        Me.rtb_detailPenjualanPacking.ReadOnly = True
        Me.rtb_detailPenjualanPacking.Size = New System.Drawing.Size(362, 270)
        Me.rtb_detailPenjualanPacking.TabIndex = 32
        Me.rtb_detailPenjualanPacking.Text = ""
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label41.Location = New System.Drawing.Point(131, 7)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(142, 18)
        Me.Label41.TabIndex = 30
        Me.Label41.Text = "Detail List Barang"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(0, 30)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(390, 1)
        Me.Label42.TabIndex = 31
        Me.Label42.Text = resources.GetString("Label42.Text")
        '
        'lbl_statusJualPacking
        '
        Me.lbl_statusJualPacking.AutoSize = True
        Me.lbl_statusJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_statusJualPacking.Location = New System.Drawing.Point(11, 158)
        Me.lbl_statusJualPacking.Name = "lbl_statusJualPacking"
        Me.lbl_statusJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_statusJualPacking.TabIndex = 31
        Me.lbl_statusJualPacking.Text = "-"
        '
        'lbl_metodeJualPacking
        '
        Me.lbl_metodeJualPacking.AutoSize = True
        Me.lbl_metodeJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_metodeJualPacking.Location = New System.Drawing.Point(11, 128)
        Me.lbl_metodeJualPacking.Name = "lbl_metodeJualPacking"
        Me.lbl_metodeJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_metodeJualPacking.TabIndex = 30
        Me.lbl_metodeJualPacking.Text = "-"
        '
        'lbl_totalJualPacking
        '
        Me.lbl_totalJualPacking.AutoSize = True
        Me.lbl_totalJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_totalJualPacking.Location = New System.Drawing.Point(11, 98)
        Me.lbl_totalJualPacking.Name = "lbl_totalJualPacking"
        Me.lbl_totalJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_totalJualPacking.TabIndex = 29
        Me.lbl_totalJualPacking.Text = "-"
        '
        'lbl_tglJualPacking
        '
        Me.lbl_tglJualPacking.AutoSize = True
        Me.lbl_tglJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tglJualPacking.Location = New System.Drawing.Point(11, 68)
        Me.lbl_tglJualPacking.Name = "lbl_tglJualPacking"
        Me.lbl_tglJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_tglJualPacking.TabIndex = 28
        Me.lbl_tglJualPacking.Text = "-"
        '
        'lbl_noJualPacking
        '
        Me.lbl_noJualPacking.AutoSize = True
        Me.lbl_noJualPacking.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_noJualPacking.Location = New System.Drawing.Point(11, 38)
        Me.lbl_noJualPacking.Name = "lbl_noJualPacking"
        Me.lbl_noJualPacking.Size = New System.Drawing.Size(13, 18)
        Me.lbl_noJualPacking.TabIndex = 27
        Me.lbl_noJualPacking.Text = "-"
        '
        'Label48
        '
        Me.Label48.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label48.Location = New System.Drawing.Point(-1, 3)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(392, 18)
        Me.Label48.TabIndex = 26
        Me.Label48.Text = "Informasi Penjualan"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label49.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(0, 26)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(390, 1)
        Me.Label49.TabIndex = 25
        Me.Label49.Text = resources.GetString("Label49.Text")
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.Button1)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel10.Location = New System.Drawing.Point(0, 580)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(390, 47)
        Me.Panel10.TabIndex = 35
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.Location = New System.Drawing.Point(13, 9)
        Me.Button1.Name = "Button1"
        Me.Button1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button1.Size = New System.Drawing.Size(366, 29)
        Me.Button1.TabIndex = 49
        Me.Button1.Text = "Clear 🧹"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'frm_ManagePenjualanPickup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1364, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximumSize = New System.Drawing.Size(1366, 768)
        Me.MinimumSize = New System.Drawing.Size(1364, 718)
        Me.Name = "frm_ManagePenjualanPickup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pic_barcodePenjualanPickup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgv_detailPenjualanPickup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgv_listPenjualanPending, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.pnl_listDetail.ResumeLayout(False)
        Me.pnl_listDetail.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        CType(Me.dgv_penjualanPackingPickup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents closeBtn As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label26 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents btnLogout As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents btnDelivery As Button
    Friend WithEvents btnPOS_Kasir As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnPickup As Button
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCancelPickup As Button
    Friend WithEvents pic_barcodePenjualanPickup As PictureBox
    Friend WithEvents Label34 As Label
    Friend WithEvents cbo_statusPickup As ComboBox
    Friend WithEvents Label33 As Label
    Friend WithEvents txt_kontakDeliveryPickup As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txt_atasNamaDeliveryPickup As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents txtJenisDeliveryPickup As TextBox
    Friend WithEvents txt_noPenjualanPickup As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents txt_catatanPickup As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents lbl_totalQtyPickup As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents cbo_metodePembayaranPickup As ComboBox
    Friend WithEvents btn_simpanPenjualanPickup As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents cbo_statusPenjualanPickup As ComboBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents lbl_subTotalPickup As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lbl_hargaSatuanPickup As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lbl_QtyPickup As Label
    Friend WithEvents lbl_grandTotalPickup As Label
    Friend WithEvents lbl_noPenjualanPickup As Label
    Friend WithEvents txt_danaDiterimaPickup As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lbl_kembalianPickup As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txt_satuanBrgPickup As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents txt_namaBrgPickup As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents cbo_brgPickup As ComboBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txt_subTotalPickup As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_hrgaPickup As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_qtyPickup As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btn_tmbhDetBeliPickup As Button
    Friend WithEvents dgv_detailPenjualanPickup As DataGridView
    Friend WithEvents dtp_tglJualPickup As DateTimePicker
    Friend WithEvents Label5 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents dgv_listPenjualanPending As DataGridView
    Friend WithEvents Panel4 As Panel
    Friend WithEvents txt_cariPenjualan As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents lbl_jenisJualPending As Label
    Friend WithEvents pnl_listDetail As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents rtb_detailPenjualan As RichTextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lbl_statusJualPending As Label
    Friend WithEvents lbl_metodeJualPending As Label
    Friend WithEvents lbl_totalJualPending As Label
    Friend WithEvents lbl_tglJualPending As Label
    Friend WithEvents lbl_noJualPending As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents btn_clearPenjualanPending As Button
    Friend WithEvents btn_updateLunasPenjualan As Button
    Friend WithEvents colNmr As DataGridViewTextBoxColumn
    Friend WithEvents colNoPenjualan As DataGridViewTextBoxColumn
    Friend WithEvents colJenis As DataGridViewTextBoxColumn
    Friend WithEvents colTglPembelian As DataGridViewTextBoxColumn
    Friend WithEvents colTotalPenjualan As DataGridViewTextBoxColumn
    Friend WithEvents colDanaDiterima As DataGridViewTextBoxColumn
    Friend WithEvents colKembalian As DataGridViewTextBoxColumn
    Friend WithEvents colMetodePembayaran As DataGridViewTextBoxColumn
    Friend WithEvents colCatatan As DataGridViewTextBoxColumn
    Friend WithEvents colAtasN As DataGridViewTextBoxColumn
    Friend WithEvents colKontak As DataGridViewTextBoxColumn
    Friend WithEvents colStatusPKirim As DataGridViewTextBoxColumn
    Friend WithEvents lbl_statusKirimPending As Label
    Friend WithEvents lbl_kontakPending As Label
    Friend WithEvents lbl_atasNamaPending As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents dgv_penjualanPackingPickup As DataGridView
    Friend WithEvents Panel7 As Panel
    Friend WithEvents txtCariPenjualanPacking As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents lbl_statusKirimPacking As Label
    Friend WithEvents lbl_kontakPacking As Label
    Friend WithEvents lbl_atasNamaPacking As Label
    Friend WithEvents lbl_jenisJualPacking As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label40 As Label
    Friend WithEvents rtb_detailPenjualanPacking As RichTextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents lbl_statusJualPacking As Label
    Friend WithEvents lbl_metodeJualPacking As Label
    Friend WithEvents lbl_totalJualPacking As Label
    Friend WithEvents lbl_tglJualPacking As Label
    Friend WithEvents lbl_noJualPacking As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents colNoPenjualanPickupPacking As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents btnSemuaListPenjualan As Button
    Friend WithEvents lbl_catatanPacking As RichTextBox
    Friend WithEvents lbl_catatanPending As RichTextBox
    Friend WithEvents txt_pickupSearchBrng As TextBox
    Friend WithEvents Label85 As Label
    Friend WithEvents lst_pickupResult As ListBox
    Friend WithEvents colNo As DataGridViewTextBoxColumn
    Friend WithEvents colKodeBrg As DataGridViewTextBoxColumn
    Friend WithEvents colNmaBrg As DataGridViewTextBoxColumn
    Friend WithEvents colQty As DataGridViewTextBoxColumn
    Friend WithEvents colSatuan As DataGridViewTextBoxColumn
    Friend WithEvents colHarga As DataGridViewTextBoxColumn
    Friend WithEvents colSubtotal As DataGridViewTextBoxColumn
    Friend WithEvents colBarcodePickup As DataGridViewTextBoxColumn
End Class

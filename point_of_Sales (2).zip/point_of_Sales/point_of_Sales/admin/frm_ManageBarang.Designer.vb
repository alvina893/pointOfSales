﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_ManageBarang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_ManageBarang))
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnPenjualan = New System.Windows.Forms.Button()
        Me.btnPembelian = New System.Windows.Forms.Button()
        Me.btnSupplier = New System.Windows.Forms.Button()
        Me.btnStokBarang = New System.Windows.Forms.Button()
        Me.btnBarang = New System.Windows.Forms.Button()
        Me.btnManageUser = New System.Windows.Forms.Button()
        Me.btnPengembalian = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnKembali = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.dgv_Barang = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKodeBarang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoBarcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipeBarcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNamaBarang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKategoriBarang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSatuanBarang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHrgaBeli = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaJualBarang = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStok = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMinStok = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colSupplierID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSupplierNama = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.txt_cariBrg = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgv_barangUbahMassal = New System.Windows.Forms.DataGridView()
        Me.colNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPilih = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.colKodeBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoBarcodeMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipeBarcodeMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNamaBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSatuanBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaBeli = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStokBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMinStokBarangMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSupplierIDMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSupplierNamaMassal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.headerSelectAll = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtcariHargaMassal = New System.Windows.Forms.TextBox()
        Me.chk_selectAllhargaMsl = New System.Windows.Forms.CheckBox()
        Me.btnUbahMassal = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btn_ResetFilter = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cbo_filterbySupplier = New System.Windows.Forms.ComboBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.dgv_BarangRiwayat = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKodeBarangRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoBarcodeRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipeBarcodeRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNamaBarangRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKategoriBarangRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSatuanBarangRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHrgaBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaJualRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStokRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMinStokRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBarcodeRiwayat = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colSupplierIDRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSupNamaRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.txt_criBrgRiwayat = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.lbl_namaBrgRiwayat = New System.Windows.Forms.Label()
        Me.dgv_tabelDetailRiwayat = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTglBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDSupRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNmaSupRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQtyRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHargaBeliRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalRiwayat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.closeBtn = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txt_barcodeValue = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_namaSup = New System.Windows.Forms.TextBox()
        Me.cbo_IDSup = New System.Windows.Forms.ComboBox()
        Me.cbo_tipeBarcode = New System.Windows.Forms.ComboBox()
        Me.txt_hrgaBeli = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btn_printBarcodeBarang = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txt_minStok = New System.Windows.Forms.TextBox()
        Me.txt_stok = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btn_tmbhSatuan = New System.Windows.Forms.Button()
        Me.btn_tmbhKategori = New System.Windows.Forms.Button()
        Me.btn_delBrg = New System.Windows.Forms.Button()
        Me.btn_clearBrg = New System.Windows.Forms.Button()
        Me.btn_updateBrg = New System.Windows.Forms.Button()
        Me.btn_simpanBrg = New System.Windows.Forms.Button()
        Me.pic_barcodeBrng = New System.Windows.Forms.PictureBox()
        Me.lblbarcode = New System.Windows.Forms.Label()
        Me.cbo_satuanBrg = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbo_kategoriBrg = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_hrgaBrg = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_nmaBrg = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_kodeBrg = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgv_Barang, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgv_barangUbahMassal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.headerSelectAll.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.dgv_BarangRiwayat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.dgv_tabelDetailRiwayat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.pic_barcodeBrng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlText
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(148, 749)
        Me.Panel2.TabIndex = 9
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.Window
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Label12)
        Me.Panel6.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel6.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel6.Controls.Add(Me.Label13)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(148, 749)
        Me.Panel6.TabIndex = 1
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(146, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(2, 768)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = resources.GetString("Label14.Text")
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Location = New System.Drawing.Point(13, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(122, 20)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Inventory System"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.btnLogout, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 693)
        Me.TableLayoutPanel2.MinimumSize = New System.Drawing.Size(142, 73)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(142, 73)
        Me.TableLayoutPanel2.TabIndex = 22
        '
        'btnLogout
        '
        Me.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.Location = New System.Drawing.Point(3, 3)
        Me.btnLogout.MinimumSize = New System.Drawing.Size(142, 67)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(142, 67)
        Me.btnLogout.TabIndex = 27
        Me.btnLogout.Text = "🔙 Logout"
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnPenjualan, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPembelian, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.btnSupplier, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.btnStokBarang, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.btnBarang, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.btnManageUser, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.btnPengembalian, 0, 5)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 68)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 7
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(148, 441)
        Me.TableLayoutPanel1.TabIndex = 21
        '
        'btnPenjualan
        '
        Me.btnPenjualan.BackColor = System.Drawing.SystemColors.Window
        Me.btnPenjualan.FlatAppearance.BorderSize = 0
        Me.btnPenjualan.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPenjualan.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPenjualan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPenjualan.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPenjualan.Location = New System.Drawing.Point(3, 251)
        Me.btnPenjualan.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnPenjualan.Name = "btnPenjualan"
        Me.btnPenjualan.Size = New System.Drawing.Size(142, 64)
        Me.btnPenjualan.TabIndex = 29
        Me.btnPenjualan.Text = "Penjualan (Sales)"
        Me.btnPenjualan.UseVisualStyleBackColor = False
        '
        'btnPembelian
        '
        Me.btnPembelian.FlatAppearance.BorderSize = 0
        Me.btnPembelian.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPembelian.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPembelian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPembelian.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPembelian.Location = New System.Drawing.Point(3, 189)
        Me.btnPembelian.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnPembelian.Name = "btnPembelian"
        Me.btnPembelian.Size = New System.Drawing.Size(142, 64)
        Me.btnPembelian.TabIndex = 25
        Me.btnPembelian.Text = "Pembelian (Purchase)"
        Me.btnPembelian.UseVisualStyleBackColor = True
        '
        'btnSupplier
        '
        Me.btnSupplier.FlatAppearance.BorderSize = 0
        Me.btnSupplier.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSupplier.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSupplier.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSupplier.Location = New System.Drawing.Point(3, 127)
        Me.btnSupplier.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnSupplier.Name = "btnSupplier"
        Me.btnSupplier.Size = New System.Drawing.Size(142, 64)
        Me.btnSupplier.TabIndex = 24
        Me.btnSupplier.Text = "Supplier"
        Me.btnSupplier.UseVisualStyleBackColor = True
        '
        'btnStokBarang
        '
        Me.btnStokBarang.FlatAppearance.BorderSize = 0
        Me.btnStokBarang.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnStokBarang.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnStokBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStokBarang.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStokBarang.Location = New System.Drawing.Point(3, 65)
        Me.btnStokBarang.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnStokBarang.Name = "btnStokBarang"
        Me.btnStokBarang.Size = New System.Drawing.Size(142, 64)
        Me.btnStokBarang.TabIndex = 23
        Me.btnStokBarang.Text = "Stok Barang (Inventaris)"
        Me.btnStokBarang.UseVisualStyleBackColor = True
        '
        'btnBarang
        '
        Me.btnBarang.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnBarang.FlatAppearance.BorderSize = 0
        Me.btnBarang.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBarang.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBarang.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBarang.Location = New System.Drawing.Point(3, 3)
        Me.btnBarang.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnBarang.Name = "btnBarang"
        Me.btnBarang.Size = New System.Drawing.Size(142, 64)
        Me.btnBarang.TabIndex = 22
        Me.btnBarang.Text = "Barang"
        Me.btnBarang.UseVisualStyleBackColor = False
        '
        'btnManageUser
        '
        Me.btnManageUser.FlatAppearance.BorderSize = 0
        Me.btnManageUser.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnManageUser.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnManageUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnManageUser.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageUser.Location = New System.Drawing.Point(3, 375)
        Me.btnManageUser.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnManageUser.Name = "btnManageUser"
        Me.btnManageUser.Size = New System.Drawing.Size(142, 64)
        Me.btnManageUser.TabIndex = 26
        Me.btnManageUser.Text = "Pengguna (Users)"
        Me.btnManageUser.UseVisualStyleBackColor = True
        '
        'btnPengembalian
        '
        Me.btnPengembalian.FlatAppearance.BorderSize = 0
        Me.btnPengembalian.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnPengembalian.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btnPengembalian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPengembalian.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPengembalian.Location = New System.Drawing.Point(3, 313)
        Me.btnPengembalian.MinimumSize = New System.Drawing.Size(142, 64)
        Me.btnPengembalian.Name = "btnPengembalian"
        Me.btnPengembalian.Size = New System.Drawing.Size(142, 64)
        Me.btnPengembalian.TabIndex = 25
        Me.btnPengembalian.Text = "Pengembalian (Retur)"
        Me.btnPengembalian.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label13.Location = New System.Drawing.Point(13, 4)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(122, 43)
        Me.Label13.TabIndex = 18
        Me.Label13.Text = "P O S"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Window
        Me.Panel1.Controls.Add(Me.btnKembali)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(148, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1218, 69)
        Me.Panel1.TabIndex = 24
        '
        'btnKembali
        '
        Me.btnKembali.AutoSize = True
        Me.btnKembali.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnKembali.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKembali.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnKembali.Location = New System.Drawing.Point(27, 23)
        Me.btnKembali.Name = "btnKembali"
        Me.btnKembali.Size = New System.Drawing.Size(26, 23)
        Me.btnKembali.TabIndex = 23
        Me.btnKembali.Text = "<"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Window
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label4.Location = New System.Drawing.Point(59, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(154, 29)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Administrator"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(148, 69)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(20, 10)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(904, 680)
        Me.TabControl1.TabIndex = 25
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.dgv_Barang)
        Me.TabPage1.Controls.Add(Me.Panel4)
        Me.TabPage1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 41)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(896, 635)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "List Barang"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'dgv_Barang
        '
        Me.dgv_Barang.AllowUserToAddRows = False
        Me.dgv_Barang.AllowUserToDeleteRows = False
        Me.dgv_Barang.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgv_Barang.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_Barang.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgv_Barang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Barang.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.colKodeBarang, Me.colNoBarcode, Me.colTipeBarcode, Me.colNamaBarang, Me.colKategoriBarang, Me.colSatuanBarang, Me.colHrgaBeli, Me.colHargaJualBarang, Me.colStok, Me.colMinStok, Me.Column8, Me.colSupplierID, Me.colSupplierNama})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_Barang.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgv_Barang.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_Barang.Location = New System.Drawing.Point(0, 50)
        Me.dgv_Barang.Name = "dgv_Barang"
        Me.dgv_Barang.ReadOnly = True
        Me.dgv_Barang.RowHeadersVisible = False
        Me.dgv_Barang.Size = New System.Drawing.Size(896, 585)
        Me.dgv_Barang.TabIndex = 15
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column1.HeaderText = "#"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 44
        '
        'colKodeBarang
        '
        Me.colKodeBarang.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colKodeBarang.HeaderText = "Kode Barang"
        Me.colKodeBarang.MinimumWidth = 117
        Me.colKodeBarang.Name = "colKodeBarang"
        Me.colKodeBarang.ReadOnly = True
        Me.colKodeBarang.Width = 117
        '
        'colNoBarcode
        '
        Me.colNoBarcode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoBarcode.HeaderText = "No. Barcode"
        Me.colNoBarcode.Name = "colNoBarcode"
        Me.colNoBarcode.ReadOnly = True
        Me.colNoBarcode.Width = 114
        '
        'colTipeBarcode
        '
        Me.colTipeBarcode.HeaderText = "Tipe Barcode"
        Me.colTipeBarcode.Name = "colTipeBarcode"
        Me.colTipeBarcode.ReadOnly = True
        Me.colTipeBarcode.Visible = False
        '
        'colNamaBarang
        '
        Me.colNamaBarang.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colNamaBarang.HeaderText = "Nama"
        Me.colNamaBarang.Name = "colNamaBarang"
        Me.colNamaBarang.ReadOnly = True
        '
        'colKategoriBarang
        '
        Me.colKategoriBarang.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colKategoriBarang.HeaderText = "Kategori"
        Me.colKategoriBarang.Name = "colKategoriBarang"
        Me.colKategoriBarang.ReadOnly = True
        Me.colKategoriBarang.Width = 86
        '
        'colSatuanBarang
        '
        Me.colSatuanBarang.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSatuanBarang.HeaderText = "Satuan"
        Me.colSatuanBarang.Name = "colSatuanBarang"
        Me.colSatuanBarang.ReadOnly = True
        Me.colSatuanBarang.Width = 78
        '
        'colHrgaBeli
        '
        Me.colHrgaBeli.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colHrgaBeli.HeaderText = "Harga Beli"
        Me.colHrgaBeli.Name = "colHrgaBeli"
        Me.colHrgaBeli.ReadOnly = True
        Me.colHrgaBeli.Width = 98
        '
        'colHargaJualBarang
        '
        Me.colHargaJualBarang.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colHargaJualBarang.HeaderText = "Harga Jual"
        Me.colHargaJualBarang.Name = "colHargaJualBarang"
        Me.colHargaJualBarang.ReadOnly = True
        Me.colHargaJualBarang.Width = 101
        '
        'colStok
        '
        Me.colStok.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colStok.HeaderText = "Stok"
        Me.colStok.Name = "colStok"
        Me.colStok.ReadOnly = True
        Me.colStok.Width = 61
        '
        'colMinStok
        '
        Me.colMinStok.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colMinStok.HeaderText = "Min Stok"
        Me.colMinStok.Name = "colMinStok"
        Me.colMinStok.ReadOnly = True
        Me.colMinStok.Width = 88
        '
        'Column8
        '
        Me.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column8.HeaderText = "Barcode"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column8.Visible = False
        Me.Column8.Width = 86
        '
        'colSupplierID
        '
        Me.colSupplierID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSupplierID.HeaderText = "Supplier ID"
        Me.colSupplierID.Name = "colSupplierID"
        Me.colSupplierID.ReadOnly = True
        Me.colSupplierID.Width = 103
        '
        'colSupplierNama
        '
        Me.colSupplierNama.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSupplierNama.HeaderText = "Nama Supplier"
        Me.colSupplierNama.Name = "colSupplierNama"
        Me.colSupplierNama.ReadOnly = True
        Me.colSupplierNama.Width = 126
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.txt_cariBrg)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(896, 50)
        Me.Panel4.TabIndex = 17
        '
        'txt_cariBrg
        '
        Me.txt_cariBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_cariBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_cariBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_cariBrg.Location = New System.Drawing.Point(114, 11)
        Me.txt_cariBrg.Name = "txt_cariBrg"
        Me.txt_cariBrg.Size = New System.Drawing.Size(240, 26)
        Me.txt_cariBrg.TabIndex = 26
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Search Barang:"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dgv_barangUbahMassal)
        Me.TabPage2.Controls.Add(Me.headerSelectAll)
        Me.TabPage2.Controls.Add(Me.Panel5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 41)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(896, 635)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Penetapan Harga Massal"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dgv_barangUbahMassal
        '
        Me.dgv_barangUbahMassal.AllowUserToAddRows = False
        Me.dgv_barangUbahMassal.AllowUserToDeleteRows = False
        Me.dgv_barangUbahMassal.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgv_barangUbahMassal.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_barangUbahMassal.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgv_barangUbahMassal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_barangUbahMassal.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNo, Me.colPilih, Me.colKodeBarangMassal, Me.colNoBarcodeMassal, Me.colTipeBarcodeMassal, Me.colNamaBarangMassal, Me.colSatuanBarangMassal, Me.colHargaBeli, Me.colHargaBarangMassal, Me.colStokBarangMassal, Me.colMinStokBarangMassal, Me.colSupplierIDMassal, Me.colSupplierNamaMassal})
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_barangUbahMassal.DefaultCellStyle = DataGridViewCellStyle12
        Me.dgv_barangUbahMassal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_barangUbahMassal.Location = New System.Drawing.Point(3, 98)
        Me.dgv_barangUbahMassal.Name = "dgv_barangUbahMassal"
        Me.dgv_barangUbahMassal.RowHeadersVisible = False
        Me.dgv_barangUbahMassal.Size = New System.Drawing.Size(890, 534)
        Me.dgv_barangUbahMassal.TabIndex = 30
        '
        'colNo
        '
        Me.colNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNo.HeaderText = "#"
        Me.colNo.Name = "colNo"
        Me.colNo.ReadOnly = True
        Me.colNo.Width = 44
        '
        'colPilih
        '
        Me.colPilih.HeaderText = "[  ]"
        Me.colPilih.MinimumWidth = 40
        Me.colPilih.Name = "colPilih"
        Me.colPilih.Visible = False
        Me.colPilih.Width = 40
        '
        'colKodeBarangMassal
        '
        Me.colKodeBarangMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKodeBarangMassal.HeaderText = "Kode Barang"
        Me.colKodeBarangMassal.MinimumWidth = 117
        Me.colKodeBarangMassal.Name = "colKodeBarangMassal"
        Me.colKodeBarangMassal.ReadOnly = True
        Me.colKodeBarangMassal.Width = 117
        '
        'colNoBarcodeMassal
        '
        Me.colNoBarcodeMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoBarcodeMassal.HeaderText = "No. Barcode"
        Me.colNoBarcodeMassal.Name = "colNoBarcodeMassal"
        Me.colNoBarcodeMassal.Width = 114
        '
        'colTipeBarcodeMassal
        '
        Me.colTipeBarcodeMassal.HeaderText = "Tipe Barcode"
        Me.colTipeBarcodeMassal.Name = "colTipeBarcodeMassal"
        Me.colTipeBarcodeMassal.Visible = False
        '
        'colNamaBarangMassal
        '
        Me.colNamaBarangMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNamaBarangMassal.HeaderText = "Nama"
        Me.colNamaBarangMassal.Name = "colNamaBarangMassal"
        Me.colNamaBarangMassal.ReadOnly = True
        '
        'colSatuanBarangMassal
        '
        Me.colSatuanBarangMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSatuanBarangMassal.HeaderText = "Satuan"
        Me.colSatuanBarangMassal.Name = "colSatuanBarangMassal"
        Me.colSatuanBarangMassal.ReadOnly = True
        Me.colSatuanBarangMassal.Width = 78
        '
        'colHargaBeli
        '
        Me.colHargaBeli.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colHargaBeli.HeaderText = "Harga Beli"
        Me.colHargaBeli.Name = "colHargaBeli"
        Me.colHargaBeli.Width = 98
        '
        'colHargaBarangMassal
        '
        Me.colHargaBarangMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colHargaBarangMassal.HeaderText = "Harga Jual"
        Me.colHargaBarangMassal.Name = "colHargaBarangMassal"
        Me.colHargaBarangMassal.ReadOnly = True
        Me.colHargaBarangMassal.Width = 101
        '
        'colStokBarangMassal
        '
        Me.colStokBarangMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colStokBarangMassal.HeaderText = "Stok"
        Me.colStokBarangMassal.Name = "colStokBarangMassal"
        Me.colStokBarangMassal.Visible = False
        '
        'colMinStokBarangMassal
        '
        Me.colMinStokBarangMassal.HeaderText = "Min Stok"
        Me.colMinStokBarangMassal.Name = "colMinStokBarangMassal"
        Me.colMinStokBarangMassal.ReadOnly = True
        Me.colMinStokBarangMassal.Visible = False
        '
        'colSupplierIDMassal
        '
        Me.colSupplierIDMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSupplierIDMassal.HeaderText = "Supplier ID"
        Me.colSupplierIDMassal.Name = "colSupplierIDMassal"
        Me.colSupplierIDMassal.ReadOnly = True
        Me.colSupplierIDMassal.Visible = False
        '
        'colSupplierNamaMassal
        '
        Me.colSupplierNamaMassal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSupplierNamaMassal.HeaderText = "Nama Supplier"
        Me.colSupplierNamaMassal.Name = "colSupplierNamaMassal"
        Me.colSupplierNamaMassal.Width = 126
        '
        'headerSelectAll
        '
        Me.headerSelectAll.Controls.Add(Me.Label21)
        Me.headerSelectAll.Controls.Add(Me.txtcariHargaMassal)
        Me.headerSelectAll.Controls.Add(Me.chk_selectAllhargaMsl)
        Me.headerSelectAll.Controls.Add(Me.btnUbahMassal)
        Me.headerSelectAll.Dock = System.Windows.Forms.DockStyle.Top
        Me.headerSelectAll.Location = New System.Drawing.Point(3, 53)
        Me.headerSelectAll.Name = "headerSelectAll"
        Me.headerSelectAll.Size = New System.Drawing.Size(890, 45)
        Me.headerSelectAll.TabIndex = 34
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(575, 15)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(96, 16)
        Me.Label21.TabIndex = 33
        Me.Label21.Text = "Search Barang:"
        '
        'txtcariHargaMassal
        '
        Me.txtcariHargaMassal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcariHargaMassal.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtcariHargaMassal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcariHargaMassal.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcariHargaMassal.Location = New System.Drawing.Point(677, 11)
        Me.txtcariHargaMassal.Name = "txtcariHargaMassal"
        Me.txtcariHargaMassal.Size = New System.Drawing.Size(200, 26)
        Me.txtcariHargaMassal.TabIndex = 32
        '
        'chk_selectAllhargaMsl
        '
        Me.chk_selectAllhargaMsl.AutoSize = True
        Me.chk_selectAllhargaMsl.Location = New System.Drawing.Point(12, 12)
        Me.chk_selectAllhargaMsl.Name = "chk_selectAllhargaMsl"
        Me.chk_selectAllhargaMsl.Size = New System.Drawing.Size(99, 22)
        Me.chk_selectAllhargaMsl.TabIndex = 31
        Me.chk_selectAllhargaMsl.Text = "Pilih Semua"
        Me.chk_selectAllhargaMsl.UseVisualStyleBackColor = True
        '
        'btnUbahMassal
        '
        Me.btnUbahMassal.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.btnUbahMassal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.btnUbahMassal.Location = New System.Drawing.Point(117, 9)
        Me.btnUbahMassal.Name = "btnUbahMassal"
        Me.btnUbahMassal.Size = New System.Drawing.Size(132, 26)
        Me.btnUbahMassal.TabIndex = 30
        Me.btnUbahMassal.Text = "✏️ Ubah Massal"
        Me.btnUbahMassal.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.btn_ResetFilter)
        Me.Panel5.Controls.Add(Me.Label19)
        Me.Panel5.Controls.Add(Me.cbo_filterbySupplier)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(3, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(890, 50)
        Me.Panel5.TabIndex = 31
        '
        'btn_ResetFilter
        '
        Me.btn_ResetFilter.Font = New System.Drawing.Font("Tahoma", 11.0!)
        Me.btn_ResetFilter.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_ResetFilter.Location = New System.Drawing.Point(336, 12)
        Me.btn_ResetFilter.Name = "btn_ResetFilter"
        Me.btn_ResetFilter.Size = New System.Drawing.Size(75, 26)
        Me.btn_ResetFilter.TabIndex = 29
        Me.btn_ResetFilter.Text = "Reset"
        Me.btn_ResetFilter.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(15, 17)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(109, 16)
        Me.Label19.TabIndex = 28
        Me.Label19.Text = "Filter by Supplier:"
        '
        'cbo_filterbySupplier
        '
        Me.cbo_filterbySupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_filterbySupplier.FormattingEnabled = True
        Me.cbo_filterbySupplier.Location = New System.Drawing.Point(130, 12)
        Me.cbo_filterbySupplier.Name = "cbo_filterbySupplier"
        Me.cbo_filterbySupplier.Size = New System.Drawing.Size(200, 26)
        Me.cbo_filterbySupplier.TabIndex = 27
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.dgv_BarangRiwayat)
        Me.TabPage3.Controls.Add(Me.Panel7)
        Me.TabPage3.Controls.Add(Me.Panel8)
        Me.TabPage3.Location = New System.Drawing.Point(4, 41)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(896, 635)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Riwayat Barang"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'dgv_BarangRiwayat
        '
        Me.dgv_BarangRiwayat.AllowUserToAddRows = False
        Me.dgv_BarangRiwayat.AllowUserToDeleteRows = False
        Me.dgv_BarangRiwayat.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgv_BarangRiwayat.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv_BarangRiwayat.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgv_BarangRiwayat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_BarangRiwayat.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.colKodeBarangRiwayat, Me.colNoBarcodeRiwayat, Me.colTipeBarcodeRiwayat, Me.colNamaBarangRiwayat, Me.colKategoriBarangRiwayat, Me.colSatuanBarangRiwayat, Me.colHrgaBeliRiwayat, Me.colHargaJualRiwayat, Me.colStokRiwayat, Me.colMinStokRiwayat, Me.colBarcodeRiwayat, Me.colSupplierIDRiwayat, Me.colSupNamaRiwayat})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv_BarangRiwayat.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgv_BarangRiwayat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_BarangRiwayat.Location = New System.Drawing.Point(3, 53)
        Me.dgv_BarangRiwayat.Name = "dgv_BarangRiwayat"
        Me.dgv_BarangRiwayat.ReadOnly = True
        Me.dgv_BarangRiwayat.RowHeadersVisible = False
        Me.dgv_BarangRiwayat.Size = New System.Drawing.Size(432, 579)
        Me.dgv_BarangRiwayat.TabIndex = 26
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn1.HeaderText = "#"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 40
        '
        'colKodeBarangRiwayat
        '
        Me.colKodeBarangRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colKodeBarangRiwayat.HeaderText = "Kode Barang"
        Me.colKodeBarangRiwayat.MinimumWidth = 117
        Me.colKodeBarangRiwayat.Name = "colKodeBarangRiwayat"
        Me.colKodeBarangRiwayat.ReadOnly = True
        Me.colKodeBarangRiwayat.Width = 117
        '
        'colNoBarcodeRiwayat
        '
        Me.colNoBarcodeRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoBarcodeRiwayat.HeaderText = "No. Barcode"
        Me.colNoBarcodeRiwayat.Name = "colNoBarcodeRiwayat"
        Me.colNoBarcodeRiwayat.ReadOnly = True
        Me.colNoBarcodeRiwayat.Width = 114
        '
        'colTipeBarcodeRiwayat
        '
        Me.colTipeBarcodeRiwayat.HeaderText = "Tipe Barcode"
        Me.colTipeBarcodeRiwayat.Name = "colTipeBarcodeRiwayat"
        Me.colTipeBarcodeRiwayat.ReadOnly = True
        Me.colTipeBarcodeRiwayat.Visible = False
        '
        'colNamaBarangRiwayat
        '
        Me.colNamaBarangRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNamaBarangRiwayat.HeaderText = "Nama"
        Me.colNamaBarangRiwayat.Name = "colNamaBarangRiwayat"
        Me.colNamaBarangRiwayat.ReadOnly = True
        '
        'colKategoriBarangRiwayat
        '
        Me.colKategoriBarangRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colKategoriBarangRiwayat.HeaderText = "Kategori"
        Me.colKategoriBarangRiwayat.Name = "colKategoriBarangRiwayat"
        Me.colKategoriBarangRiwayat.ReadOnly = True
        Me.colKategoriBarangRiwayat.Visible = False
        Me.colKategoriBarangRiwayat.Width = 86
        '
        'colSatuanBarangRiwayat
        '
        Me.colSatuanBarangRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSatuanBarangRiwayat.HeaderText = "Satuan"
        Me.colSatuanBarangRiwayat.Name = "colSatuanBarangRiwayat"
        Me.colSatuanBarangRiwayat.ReadOnly = True
        Me.colSatuanBarangRiwayat.Visible = False
        Me.colSatuanBarangRiwayat.Width = 78
        '
        'colHrgaBeliRiwayat
        '
        Me.colHrgaBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colHrgaBeliRiwayat.HeaderText = "Harga Beli"
        Me.colHrgaBeliRiwayat.Name = "colHrgaBeliRiwayat"
        Me.colHrgaBeliRiwayat.ReadOnly = True
        Me.colHrgaBeliRiwayat.Visible = False
        Me.colHrgaBeliRiwayat.Width = 165
        '
        'colHargaJualRiwayat
        '
        Me.colHargaJualRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colHargaJualRiwayat.HeaderText = "Harga Jual"
        Me.colHargaJualRiwayat.Name = "colHargaJualRiwayat"
        Me.colHargaJualRiwayat.ReadOnly = True
        Me.colHargaJualRiwayat.Visible = False
        Me.colHargaJualRiwayat.Width = 101
        '
        'colStokRiwayat
        '
        Me.colStokRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colStokRiwayat.HeaderText = "Stok"
        Me.colStokRiwayat.Name = "colStokRiwayat"
        Me.colStokRiwayat.ReadOnly = True
        Me.colStokRiwayat.Width = 90
        '
        'colMinStokRiwayat
        '
        Me.colMinStokRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colMinStokRiwayat.HeaderText = "Min Stok"
        Me.colMinStokRiwayat.Name = "colMinStokRiwayat"
        Me.colMinStokRiwayat.ReadOnly = True
        Me.colMinStokRiwayat.Visible = False
        Me.colMinStokRiwayat.Width = 88
        '
        'colBarcodeRiwayat
        '
        Me.colBarcodeRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colBarcodeRiwayat.HeaderText = "Barcode"
        Me.colBarcodeRiwayat.Name = "colBarcodeRiwayat"
        Me.colBarcodeRiwayat.ReadOnly = True
        Me.colBarcodeRiwayat.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colBarcodeRiwayat.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colBarcodeRiwayat.Visible = False
        Me.colBarcodeRiwayat.Width = 86
        '
        'colSupplierIDRiwayat
        '
        Me.colSupplierIDRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSupplierIDRiwayat.HeaderText = "Supplier ID"
        Me.colSupplierIDRiwayat.Name = "colSupplierIDRiwayat"
        Me.colSupplierIDRiwayat.ReadOnly = True
        Me.colSupplierIDRiwayat.Visible = False
        Me.colSupplierIDRiwayat.Width = 103
        '
        'colSupNamaRiwayat
        '
        Me.colSupNamaRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colSupNamaRiwayat.HeaderText = "Nama Supplier"
        Me.colSupNamaRiwayat.Name = "colSupNamaRiwayat"
        Me.colSupNamaRiwayat.ReadOnly = True
        Me.colSupNamaRiwayat.Visible = False
        Me.colSupNamaRiwayat.Width = 126
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.txt_criBrgRiwayat)
        Me.Panel7.Controls.Add(Me.Label25)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel7.Location = New System.Drawing.Point(3, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(432, 50)
        Me.Panel7.TabIndex = 27
        '
        'txt_criBrgRiwayat
        '
        Me.txt_criBrgRiwayat.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_criBrgRiwayat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_criBrgRiwayat.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_criBrgRiwayat.Location = New System.Drawing.Point(114, 11)
        Me.txt_criBrgRiwayat.Name = "txt_criBrgRiwayat"
        Me.txt_criBrgRiwayat.Size = New System.Drawing.Size(240, 26)
        Me.txt_criBrgRiwayat.TabIndex = 26
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(15, 16)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(96, 16)
        Me.Label25.TabIndex = 25
        Me.Label25.Text = "Search Barang:"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.Window
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.Panel9)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel8.Location = New System.Drawing.Point(435, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(458, 629)
        Me.Panel8.TabIndex = 28
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.lbl_namaBrgRiwayat)
        Me.Panel9.Controls.Add(Me.dgv_tabelDetailRiwayat)
        Me.Panel9.Controls.Add(Me.Label27)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(0, -20)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(456, 647)
        Me.Panel9.TabIndex = 21
        '
        'lbl_namaBrgRiwayat
        '
        Me.lbl_namaBrgRiwayat.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_namaBrgRiwayat.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lbl_namaBrgRiwayat.Location = New System.Drawing.Point(1, 27)
        Me.lbl_namaBrgRiwayat.Name = "lbl_namaBrgRiwayat"
        Me.lbl_namaBrgRiwayat.Size = New System.Drawing.Size(454, 18)
        Me.lbl_namaBrgRiwayat.TabIndex = 31
        Me.lbl_namaBrgRiwayat.Text = "<Nama Barang>"
        Me.lbl_namaBrgRiwayat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dgv_tabelDetailRiwayat
        '
        Me.dgv_tabelDetailRiwayat.AllowUserToAddRows = False
        Me.dgv_tabelDetailRiwayat.AllowUserToDeleteRows = False
        Me.dgv_tabelDetailRiwayat.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv_tabelDetailRiwayat.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv_tabelDetailRiwayat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_tabelDetailRiwayat.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.colTglBeliRiwayat, Me.colNoBeliRiwayat, Me.colIDSupRiwayat, Me.colNmaSupRiwayat, Me.colQtyRiwayat, Me.colHargaBeliRiwayat, Me.colTotalRiwayat})
        Me.dgv_tabelDetailRiwayat.Location = New System.Drawing.Point(-1, 50)
        Me.dgv_tabelDetailRiwayat.Name = "dgv_tabelDetailRiwayat"
        Me.dgv_tabelDetailRiwayat.ReadOnly = True
        Me.dgv_tabelDetailRiwayat.RowHeadersVisible = False
        Me.dgv_tabelDetailRiwayat.Size = New System.Drawing.Size(456, 599)
        Me.dgv_tabelDetailRiwayat.TabIndex = 25
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.HeaderText = "#"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 44
        '
        'colTglBeliRiwayat
        '
        Me.colTglBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTglBeliRiwayat.HeaderText = "Tgl. Beli"
        Me.colTglBeliRiwayat.Name = "colTglBeliRiwayat"
        Me.colTglBeliRiwayat.ReadOnly = True
        Me.colTglBeliRiwayat.Width = 84
        '
        'colNoBeliRiwayat
        '
        Me.colNoBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNoBeliRiwayat.HeaderText = "No. Pembelian"
        Me.colNoBeliRiwayat.Name = "colNoBeliRiwayat"
        Me.colNoBeliRiwayat.ReadOnly = True
        Me.colNoBeliRiwayat.Width = 126
        '
        'colIDSupRiwayat
        '
        Me.colIDSupRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIDSupRiwayat.HeaderText = "Supplier ID"
        Me.colIDSupRiwayat.Name = "colIDSupRiwayat"
        Me.colIDSupRiwayat.ReadOnly = True
        Me.colIDSupRiwayat.Width = 103
        '
        'colNmaSupRiwayat
        '
        Me.colNmaSupRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNmaSupRiwayat.HeaderText = "Nama Supplier"
        Me.colNmaSupRiwayat.Name = "colNmaSupRiwayat"
        Me.colNmaSupRiwayat.ReadOnly = True
        Me.colNmaSupRiwayat.Width = 126
        '
        'colQtyRiwayat
        '
        Me.colQtyRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colQtyRiwayat.HeaderText = "Qty"
        Me.colQtyRiwayat.Name = "colQtyRiwayat"
        Me.colQtyRiwayat.ReadOnly = True
        Me.colQtyRiwayat.Width = 57
        '
        'colHargaBeliRiwayat
        '
        Me.colHargaBeliRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colHargaBeliRiwayat.HeaderText = "Harga Beli"
        Me.colHargaBeliRiwayat.Name = "colHargaBeliRiwayat"
        Me.colHargaBeliRiwayat.ReadOnly = True
        Me.colHargaBeliRiwayat.Width = 98
        '
        'colTotalRiwayat
        '
        Me.colTotalRiwayat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotalRiwayat.HeaderText = "Total"
        Me.colTotalRiwayat.Name = "colTotalRiwayat"
        Me.colTotalRiwayat.ReadOnly = True
        Me.colTotalRiwayat.Width = 66
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label27.Location = New System.Drawing.Point(1, 7)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(454, 18)
        Me.Label27.TabIndex = 30
        Me.Label27.Text = "Detail Riwayat Barang:"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'closeBtn
        '
        Me.closeBtn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeBtn.ForeColor = System.Drawing.Color.Maroon
        Me.closeBtn.Location = New System.Drawing.Point(1305, 12)
        Me.closeBtn.Name = "closeBtn"
        Me.closeBtn.Size = New System.Drawing.Size(49, 30)
        Me.closeBtn.TabIndex = 6
        Me.closeBtn.Text = "| X |"
        Me.closeBtn.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.txt_barcodeValue)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.Label11)
        Me.Panel3.Controls.Add(Me.txt_namaSup)
        Me.Panel3.Controls.Add(Me.cbo_IDSup)
        Me.Panel3.Controls.Add(Me.cbo_tipeBarcode)
        Me.Panel3.Controls.Add(Me.txt_hrgaBeli)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.btn_printBarcodeBarang)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.txt_minStok)
        Me.Panel3.Controls.Add(Me.txt_stok)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.btn_tmbhSatuan)
        Me.Panel3.Controls.Add(Me.btn_tmbhKategori)
        Me.Panel3.Controls.Add(Me.btn_delBrg)
        Me.Panel3.Controls.Add(Me.btn_clearBrg)
        Me.Panel3.Controls.Add(Me.btn_updateBrg)
        Me.Panel3.Controls.Add(Me.btn_simpanBrg)
        Me.Panel3.Controls.Add(Me.pic_barcodeBrng)
        Me.Panel3.Controls.Add(Me.lblbarcode)
        Me.Panel3.Controls.Add(Me.cbo_satuanBrg)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.cbo_kategoriBrg)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.txt_hrgaBrg)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.txt_nmaBrg)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.txt_kodeBrg)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(1052, 69)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(314, 680)
        Me.Panel3.TabIndex = 26
        '
        'txt_barcodeValue
        '
        Me.txt_barcodeValue.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_barcodeValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_barcodeValue.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_barcodeValue.Location = New System.Drawing.Point(15, 165)
        Me.txt_barcodeValue.Name = "txt_barcodeValue"
        Me.txt_barcodeValue.Size = New System.Drawing.Size(283, 26)
        Me.txt_barcodeValue.TabIndex = 66
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(159, 482)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 16)
        Me.Label17.TabIndex = 62
        Me.Label17.Text = "Nama Supplier:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(12, 146)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(81, 16)
        Me.Label20.TabIndex = 65
        Me.Label20.Text = "No. Barcode:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(12, 482)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(75, 16)
        Me.Label18.TabIndex = 61
        Me.Label18.Text = "ID Supplier:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 90)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 16)
        Me.Label11.TabIndex = 64
        Me.Label11.Text = "Tipe Barcode:"
        '
        'txt_namaSup
        '
        Me.txt_namaSup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_namaSup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_namaSup.Enabled = False
        Me.txt_namaSup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_namaSup.Location = New System.Drawing.Point(162, 501)
        Me.txt_namaSup.Name = "txt_namaSup"
        Me.txt_namaSup.ReadOnly = True
        Me.txt_namaSup.Size = New System.Drawing.Size(138, 26)
        Me.txt_namaSup.TabIndex = 60
        '
        'cbo_IDSup
        '
        Me.cbo_IDSup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_IDSup.FormattingEnabled = True
        Me.cbo_IDSup.Location = New System.Drawing.Point(15, 500)
        Me.cbo_IDSup.Name = "cbo_IDSup"
        Me.cbo_IDSup.Size = New System.Drawing.Size(138, 26)
        Me.cbo_IDSup.TabIndex = 59
        '
        'cbo_tipeBarcode
        '
        Me.cbo_tipeBarcode.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_tipeBarcode.FormattingEnabled = True
        Me.cbo_tipeBarcode.Items.AddRange(New Object() {"Generate Barcode", "Barcode dari Barang"})
        Me.cbo_tipeBarcode.Location = New System.Drawing.Point(15, 109)
        Me.cbo_tipeBarcode.Name = "cbo_tipeBarcode"
        Me.cbo_tipeBarcode.Size = New System.Drawing.Size(285, 26)
        Me.cbo_tipeBarcode.TabIndex = 63
        '
        'txt_hrgaBeli
        '
        Me.txt_hrgaBeli.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_hrgaBeli.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_hrgaBeli.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_hrgaBeli.Location = New System.Drawing.Point(15, 389)
        Me.txt_hrgaBeli.Name = "txt_hrgaBeli"
        Me.txt_hrgaBeli.Size = New System.Drawing.Size(138, 26)
        Me.txt_hrgaBeli.TabIndex = 58
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(12, 370)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 16)
        Me.Label10.TabIndex = 57
        Me.Label10.Text = "Harga Beli:"
        '
        'btn_printBarcodeBarang
        '
        Me.btn_printBarcodeBarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_printBarcodeBarang.FlatAppearance.BorderSize = 0
        Me.btn_printBarcodeBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_printBarcodeBarang.Font = New System.Drawing.Font("Tahoma", 11.25!)
        Me.btn_printBarcodeBarang.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_printBarcodeBarang.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_printBarcodeBarang.Location = New System.Drawing.Point(252, 556)
        Me.btn_printBarcodeBarang.Name = "btn_printBarcodeBarang"
        Me.btn_printBarcodeBarang.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_printBarcodeBarang.Size = New System.Drawing.Size(48, 60)
        Me.btn_printBarcodeBarang.TabIndex = 56
        Me.btn_printBarcodeBarang.Text = "Print 🖨️"
        Me.btn_printBarcodeBarang.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(159, 426)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 16)
        Me.Label16.TabIndex = 55
        Me.Label16.Text = "Min Stok:"
        '
        'txt_minStok
        '
        Me.txt_minStok.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_minStok.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_minStok.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_minStok.Location = New System.Drawing.Point(162, 445)
        Me.txt_minStok.Name = "txt_minStok"
        Me.txt_minStok.Size = New System.Drawing.Size(138, 26)
        Me.txt_minStok.TabIndex = 54
        '
        'txt_stok
        '
        Me.txt_stok.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_stok.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_stok.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_stok.Location = New System.Drawing.Point(15, 445)
        Me.txt_stok.Name = "txt_stok"
        Me.txt_stok.Size = New System.Drawing.Size(138, 26)
        Me.txt_stok.TabIndex = 53
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(12, 426)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(37, 16)
        Me.Label15.TabIndex = 52
        Me.Label15.Text = "Stok:"
        '
        'btn_tmbhSatuan
        '
        Me.btn_tmbhSatuan.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_tmbhSatuan.FlatAppearance.BorderSize = 0
        Me.btn_tmbhSatuan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tmbhSatuan.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_tmbhSatuan.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_tmbhSatuan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhSatuan.Location = New System.Drawing.Point(252, 333)
        Me.btn_tmbhSatuan.Name = "btn_tmbhSatuan"
        Me.btn_tmbhSatuan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_tmbhSatuan.Size = New System.Drawing.Size(48, 26)
        Me.btn_tmbhSatuan.TabIndex = 49
        Me.btn_tmbhSatuan.Text = "➕"
        Me.btn_tmbhSatuan.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhSatuan.UseVisualStyleBackColor = False
        '
        'btn_tmbhKategori
        '
        Me.btn_tmbhKategori.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_tmbhKategori.FlatAppearance.BorderSize = 0
        Me.btn_tmbhKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tmbhKategori.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_tmbhKategori.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_tmbhKategori.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhKategori.Location = New System.Drawing.Point(252, 277)
        Me.btn_tmbhKategori.Name = "btn_tmbhKategori"
        Me.btn_tmbhKategori.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_tmbhKategori.Size = New System.Drawing.Size(48, 26)
        Me.btn_tmbhKategori.TabIndex = 48
        Me.btn_tmbhKategori.Text = "➕"
        Me.btn_tmbhKategori.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhKategori.UseVisualStyleBackColor = False
        '
        'btn_delBrg
        '
        Me.btn_delBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(218, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.btn_delBrg.FlatAppearance.BorderSize = 0
        Me.btn_delBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_delBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_delBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_delBrg.Location = New System.Drawing.Point(164, 660)
        Me.btn_delBrg.Name = "btn_delBrg"
        Me.btn_delBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_delBrg.Size = New System.Drawing.Size(138, 26)
        Me.btn_delBrg.TabIndex = 47
        Me.btn_delBrg.Text = "Delete 🗑️"
        Me.btn_delBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_delBrg.UseVisualStyleBackColor = False
        '
        'btn_clearBrg
        '
        Me.btn_clearBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_clearBrg.FlatAppearance.BorderSize = 0
        Me.btn_clearBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_clearBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_clearBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_clearBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_clearBrg.Location = New System.Drawing.Point(17, 660)
        Me.btn_clearBrg.Name = "btn_clearBrg"
        Me.btn_clearBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_clearBrg.Size = New System.Drawing.Size(138, 26)
        Me.btn_clearBrg.TabIndex = 46
        Me.btn_clearBrg.Text = "Clear 🧹"
        Me.btn_clearBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_clearBrg.UseVisualStyleBackColor = False
        '
        'btn_updateBrg
        '
        Me.btn_updateBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(56, Byte), Integer))
        Me.btn_updateBrg.FlatAppearance.BorderSize = 0
        Me.btn_updateBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_updateBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_updateBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_updateBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateBrg.Location = New System.Drawing.Point(164, 626)
        Me.btn_updateBrg.Name = "btn_updateBrg"
        Me.btn_updateBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_updateBrg.Size = New System.Drawing.Size(138, 26)
        Me.btn_updateBrg.TabIndex = 45
        Me.btn_updateBrg.Text = "Update ✏️"
        Me.btn_updateBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_updateBrg.UseVisualStyleBackColor = False
        '
        'btn_simpanBrg
        '
        Me.btn_simpanBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_simpanBrg.FlatAppearance.BorderSize = 0
        Me.btn_simpanBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_simpanBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_simpanBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_simpanBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_simpanBrg.Location = New System.Drawing.Point(17, 626)
        Me.btn_simpanBrg.Name = "btn_simpanBrg"
        Me.btn_simpanBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_simpanBrg.Size = New System.Drawing.Size(138, 26)
        Me.btn_simpanBrg.TabIndex = 44
        Me.btn_simpanBrg.Text = "Simpan 💾"
        Me.btn_simpanBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_simpanBrg.UseVisualStyleBackColor = False
        '
        'pic_barcodeBrng
        '
        Me.pic_barcodeBrng.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pic_barcodeBrng.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pic_barcodeBrng.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_barcodeBrng.Location = New System.Drawing.Point(15, 547)
        Me.pic_barcodeBrng.Name = "pic_barcodeBrng"
        Me.pic_barcodeBrng.Size = New System.Drawing.Size(231, 60)
        Me.pic_barcodeBrng.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_barcodeBrng.TabIndex = 42
        Me.pic_barcodeBrng.TabStop = False
        '
        'lblbarcode
        '
        Me.lblbarcode.AutoSize = True
        Me.lblbarcode.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbarcode.Location = New System.Drawing.Point(12, 537)
        Me.lblbarcode.Name = "lblbarcode"
        Me.lblbarcode.Size = New System.Drawing.Size(58, 16)
        Me.lblbarcode.TabIndex = 40
        Me.lblbarcode.Text = "Barcode:"
        '
        'cbo_satuanBrg
        '
        Me.cbo_satuanBrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_satuanBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_satuanBrg.FormattingEnabled = True
        Me.cbo_satuanBrg.Location = New System.Drawing.Point(15, 333)
        Me.cbo_satuanBrg.Name = "cbo_satuanBrg"
        Me.cbo_satuanBrg.Size = New System.Drawing.Size(231, 26)
        Me.cbo_satuanBrg.TabIndex = 37
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(12, 314)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 16)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "Satuan:"
        '
        'cbo_kategoriBrg
        '
        Me.cbo_kategoriBrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_kategoriBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_kategoriBrg.FormattingEnabled = True
        Me.cbo_kategoriBrg.Location = New System.Drawing.Point(15, 277)
        Me.cbo_kategoriBrg.Name = "cbo_kategoriBrg"
        Me.cbo_kategoriBrg.Size = New System.Drawing.Size(231, 26)
        Me.cbo_kategoriBrg.TabIndex = 35
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(12, 258)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 16)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Kategori:"
        '
        'txt_hrgaBrg
        '
        Me.txt_hrgaBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_hrgaBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_hrgaBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_hrgaBrg.Location = New System.Drawing.Point(162, 389)
        Me.txt_hrgaBrg.Name = "txt_hrgaBrg"
        Me.txt_hrgaBrg.Size = New System.Drawing.Size(138, 26)
        Me.txt_hrgaBrg.TabIndex = 33
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(159, 370)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 16)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Harga Jual:"
        '
        'txt_nmaBrg
        '
        Me.txt_nmaBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_nmaBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_nmaBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_nmaBrg.Location = New System.Drawing.Point(15, 221)
        Me.txt_nmaBrg.Name = "txt_nmaBrg"
        Me.txt_nmaBrg.Size = New System.Drawing.Size(285, 26)
        Me.txt_nmaBrg.TabIndex = 31
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(12, 202)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 16)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Nama Barang:"
        '
        'txt_kodeBrg
        '
        Me.txt_kodeBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_kodeBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_kodeBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_kodeBrg.Location = New System.Drawing.Point(15, 55)
        Me.txt_kodeBrg.Name = "txt_kodeBrg"
        Me.txt_kodeBrg.Size = New System.Drawing.Size(285, 26)
        Me.txt_kodeBrg.TabIndex = 29
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 16)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Kode Barang:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(312, 1)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = resources.GetString("Label2.Text")
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(309, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Management Barang"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frm_ManageBarang
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1366, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.closeBtn)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximumSize = New System.Drawing.Size(1366, 768)
        Me.MinimumSize = New System.Drawing.Size(1364, 718)
        Me.Name = "frm_ManageBarang"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_ManageBarang"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.dgv_Barang, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgv_barangUbahMassal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.headerSelectAll.ResumeLayout(False)
        Me.headerSelectAll.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.dgv_BarangRiwayat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        CType(Me.dgv_tabelDetailRiwayat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.pic_barcodeBrng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents btnLogout As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents btnPengembalian As Button
    Friend WithEvents btnPembelian As Button
    Friend WithEvents btnSupplier As Button
    Friend WithEvents btnStokBarang As Button
    Friend WithEvents btnBarang As Button
    Friend WithEvents btnManageUser As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents dgv_Barang As DataGridView
    Friend WithEvents Panel4 As Panel
    Friend WithEvents txt_cariBrg As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btnKembali As Label
    Friend WithEvents btnPenjualan As Button
    Friend WithEvents closeBtn As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents dgv_barangUbahMassal As DataGridView
    Friend WithEvents Panel5 As Panel
    Friend WithEvents btn_ResetFilter As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents cbo_filterbySupplier As ComboBox
    Friend WithEvents headerSelectAll As Panel
    Friend WithEvents btnUbahMassal As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents cbo_tipeBarcode As ComboBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txt_namaSup As TextBox
    Friend WithEvents cbo_IDSup As ComboBox
    Friend WithEvents txt_hrgaBeli As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents btn_printBarcodeBarang As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents txt_minStok As TextBox
    Friend WithEvents txt_stok As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents btn_tmbhSatuan As Button
    Friend WithEvents btn_tmbhKategori As Button
    Friend WithEvents btn_delBrg As Button
    Friend WithEvents btn_clearBrg As Button
    Friend WithEvents btn_updateBrg As Button
    Friend WithEvents btn_simpanBrg As Button
    Friend WithEvents pic_barcodeBrng As PictureBox
    Friend WithEvents lblbarcode As Label
    Friend WithEvents cbo_satuanBrg As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cbo_kategoriBrg As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_hrgaBrg As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_nmaBrg As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_kodeBrg As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_barcodeValue As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents chk_selectAllhargaMsl As CheckBox
    Friend WithEvents colNo As DataGridViewTextBoxColumn
    Friend WithEvents colPilih As DataGridViewCheckBoxColumn
    Friend WithEvents colKodeBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colNoBarcodeMassal As DataGridViewTextBoxColumn
    Friend WithEvents colTipeBarcodeMassal As DataGridViewTextBoxColumn
    Friend WithEvents colNamaBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colSatuanBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colHargaBeli As DataGridViewTextBoxColumn
    Friend WithEvents colHargaBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colStokBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colMinStokBarangMassal As DataGridViewTextBoxColumn
    Friend WithEvents colSupplierIDMassal As DataGridViewTextBoxColumn
    Friend WithEvents colSupplierNamaMassal As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents colKodeBarang As DataGridViewTextBoxColumn
    Friend WithEvents colNoBarcode As DataGridViewTextBoxColumn
    Friend WithEvents colTipeBarcode As DataGridViewTextBoxColumn
    Friend WithEvents colNamaBarang As DataGridViewTextBoxColumn
    Friend WithEvents colKategoriBarang As DataGridViewTextBoxColumn
    Friend WithEvents colSatuanBarang As DataGridViewTextBoxColumn
    Friend WithEvents colHrgaBeli As DataGridViewTextBoxColumn
    Friend WithEvents colHargaJualBarang As DataGridViewTextBoxColumn
    Friend WithEvents colStok As DataGridViewTextBoxColumn
    Friend WithEvents colMinStok As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewImageColumn
    Friend WithEvents colSupplierID As DataGridViewTextBoxColumn
    Friend WithEvents colSupplierNama As DataGridViewTextBoxColumn
    Friend WithEvents txtcariHargaMassal As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents dgv_BarangRiwayat As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents colKodeBarangRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNoBarcodeRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colTipeBarcodeRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNamaBarangRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colKategoriBarangRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colSatuanBarangRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colHrgaBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colHargaJualRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colStokRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colMinStokRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colBarcodeRiwayat As DataGridViewImageColumn
    Friend WithEvents colSupplierIDRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colSupNamaRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents Panel7 As Panel
    Friend WithEvents txt_criBrgRiwayat As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents dgv_tabelDetailRiwayat As DataGridView
    Friend WithEvents Label27 As Label
    Friend WithEvents lbl_namaBrgRiwayat As Label
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents colTglBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNoBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colIDSupRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colNmaSupRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colQtyRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colHargaBeliRiwayat As DataGridViewTextBoxColumn
    Friend WithEvents colTotalRiwayat As DataGridViewTextBoxColumn
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_PopUpBarangBaru
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.closeBtn = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txt_namaSup = New System.Windows.Forms.TextBox()
        Me.cbo_idSup = New System.Windows.Forms.ComboBox()
        Me.txt_hrgaBeli = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txt_minStok = New System.Windows.Forms.TextBox()
        Me.txt_stok = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btn_tmbhSatuan = New System.Windows.Forms.Button()
        Me.btn_tmbhKategori = New System.Windows.Forms.Button()
        Me.pic_barcodeBrg = New System.Windows.Forms.PictureBox()
        Me.lblgenerateBarcode = New System.Windows.Forms.Label()
        Me.cbo_satuanBrg = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbo_kategoriBrg = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_hrgaBrg = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_nmaBrg = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_kodeBrg = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btn_delBrg = New System.Windows.Forms.Button()
        Me.btn_simpanBrg = New System.Windows.Forms.Button()
        Me.txt_barcodeValue = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbo_tipeBarcode = New System.Windows.Forms.ComboBox()
        Me.btn_printBarcodeBarang = New System.Windows.Forms.Button()
        CType(Me.pic_barcodeBrg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(28, 51)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(495, 2)
        Me.Label6.TabIndex = 60
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(219, 23)
        Me.Label1.TabIndex = 59
        Me.Label1.Text = "Tambah Barang BARU"
        '
        'closeBtn
        '
        Me.closeBtn.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeBtn.ForeColor = System.Drawing.Color.Maroon
        Me.closeBtn.Location = New System.Drawing.Point(475, 12)
        Me.closeBtn.Name = "closeBtn"
        Me.closeBtn.Size = New System.Drawing.Size(49, 30)
        Me.closeBtn.TabIndex = 58
        Me.closeBtn.Text = "| X |"
        Me.closeBtn.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(281, 411)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(96, 16)
        Me.Label17.TabIndex = 86
        Me.Label17.Text = "Nama Supplier:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(27, 411)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(75, 16)
        Me.Label18.TabIndex = 85
        Me.Label18.Text = "ID Supplier:"
        '
        'txt_namaSup
        '
        Me.txt_namaSup.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_namaSup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_namaSup.Enabled = False
        Me.txt_namaSup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_namaSup.Location = New System.Drawing.Point(284, 430)
        Me.txt_namaSup.Name = "txt_namaSup"
        Me.txt_namaSup.ReadOnly = True
        Me.txt_namaSup.Size = New System.Drawing.Size(240, 26)
        Me.txt_namaSup.TabIndex = 84
        '
        'cbo_idSup
        '
        Me.cbo_idSup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_idSup.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_idSup.FormattingEnabled = True
        Me.cbo_idSup.Location = New System.Drawing.Point(29, 430)
        Me.cbo_idSup.Name = "cbo_idSup"
        Me.cbo_idSup.Size = New System.Drawing.Size(241, 26)
        Me.cbo_idSup.TabIndex = 83
        '
        'txt_hrgaBeli
        '
        Me.txt_hrgaBeli.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_hrgaBeli.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_hrgaBeli.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_hrgaBeli.Location = New System.Drawing.Point(30, 314)
        Me.txt_hrgaBeli.Name = "txt_hrgaBeli"
        Me.txt_hrgaBeli.Size = New System.Drawing.Size(240, 26)
        Me.txt_hrgaBeli.TabIndex = 82
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(27, 295)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 16)
        Me.Label10.TabIndex = 81
        Me.Label10.Text = "Harga Beli:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(281, 353)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 16)
        Me.Label16.TabIndex = 80
        Me.Label16.Text = "Min Stok:"
        '
        'txt_minStok
        '
        Me.txt_minStok.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_minStok.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_minStok.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_minStok.Location = New System.Drawing.Point(284, 372)
        Me.txt_minStok.Name = "txt_minStok"
        Me.txt_minStok.Size = New System.Drawing.Size(240, 26)
        Me.txt_minStok.TabIndex = 79
        '
        'txt_stok
        '
        Me.txt_stok.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_stok.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_stok.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_stok.Location = New System.Drawing.Point(30, 372)
        Me.txt_stok.Name = "txt_stok"
        Me.txt_stok.Size = New System.Drawing.Size(240, 26)
        Me.txt_stok.TabIndex = 78
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(27, 353)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(37, 16)
        Me.Label15.TabIndex = 77
        Me.Label15.Text = "Stok:"
        '
        'btn_tmbhSatuan
        '
        Me.btn_tmbhSatuan.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_tmbhSatuan.FlatAppearance.BorderSize = 0
        Me.btn_tmbhSatuan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tmbhSatuan.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_tmbhSatuan.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_tmbhSatuan.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhSatuan.Location = New System.Drawing.Point(476, 256)
        Me.btn_tmbhSatuan.Name = "btn_tmbhSatuan"
        Me.btn_tmbhSatuan.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_tmbhSatuan.Size = New System.Drawing.Size(48, 26)
        Me.btn_tmbhSatuan.TabIndex = 76
        Me.btn_tmbhSatuan.Text = "➕"
        Me.btn_tmbhSatuan.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhSatuan.UseVisualStyleBackColor = False
        '
        'btn_tmbhKategori
        '
        Me.btn_tmbhKategori.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_tmbhKategori.FlatAppearance.BorderSize = 0
        Me.btn_tmbhKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_tmbhKategori.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_tmbhKategori.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_tmbhKategori.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhKategori.Location = New System.Drawing.Point(222, 256)
        Me.btn_tmbhKategori.Name = "btn_tmbhKategori"
        Me.btn_tmbhKategori.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_tmbhKategori.Size = New System.Drawing.Size(48, 26)
        Me.btn_tmbhKategori.TabIndex = 75
        Me.btn_tmbhKategori.Text = "➕"
        Me.btn_tmbhKategori.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_tmbhKategori.UseVisualStyleBackColor = False
        '
        'pic_barcodeBrg
        '
        Me.pic_barcodeBrg.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pic_barcodeBrg.BackColor = System.Drawing.SystemColors.Window
        Me.pic_barcodeBrg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pic_barcodeBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic_barcodeBrg.Location = New System.Drawing.Point(31, 487)
        Me.pic_barcodeBrg.Name = "pic_barcodeBrg"
        Me.pic_barcodeBrg.Size = New System.Drawing.Size(439, 50)
        Me.pic_barcodeBrg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_barcodeBrg.TabIndex = 74
        Me.pic_barcodeBrg.TabStop = False
        '
        'lblgenerateBarcode
        '
        Me.lblgenerateBarcode.AutoSize = True
        Me.lblgenerateBarcode.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgenerateBarcode.Location = New System.Drawing.Point(27, 468)
        Me.lblgenerateBarcode.Name = "lblgenerateBarcode"
        Me.lblgenerateBarcode.Size = New System.Drawing.Size(114, 16)
        Me.lblgenerateBarcode.TabIndex = 73
        Me.lblgenerateBarcode.Text = "Generate Barcode:"
        '
        'cbo_satuanBrg
        '
        Me.cbo_satuanBrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_satuanBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_satuanBrg.FormattingEnabled = True
        Me.cbo_satuanBrg.Location = New System.Drawing.Point(284, 256)
        Me.cbo_satuanBrg.Name = "cbo_satuanBrg"
        Me.cbo_satuanBrg.Size = New System.Drawing.Size(185, 26)
        Me.cbo_satuanBrg.TabIndex = 72
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(281, 237)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 16)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "Satuan:"
        '
        'cbo_kategoriBrg
        '
        Me.cbo_kategoriBrg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_kategoriBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_kategoriBrg.FormattingEnabled = True
        Me.cbo_kategoriBrg.Location = New System.Drawing.Point(30, 256)
        Me.cbo_kategoriBrg.Name = "cbo_kategoriBrg"
        Me.cbo_kategoriBrg.Size = New System.Drawing.Size(185, 26)
        Me.cbo_kategoriBrg.TabIndex = 70
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(27, 237)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 16)
        Me.Label8.TabIndex = 69
        Me.Label8.Text = "Kategori:"
        '
        'txt_hrgaBrg
        '
        Me.txt_hrgaBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_hrgaBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_hrgaBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_hrgaBrg.Location = New System.Drawing.Point(284, 314)
        Me.txt_hrgaBrg.Name = "txt_hrgaBrg"
        Me.txt_hrgaBrg.Size = New System.Drawing.Size(240, 26)
        Me.txt_hrgaBrg.TabIndex = 68
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(281, 295)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 16)
        Me.Label7.TabIndex = 67
        Me.Label7.Text = "Harga Jual:"
        '
        'txt_nmaBrg
        '
        Me.txt_nmaBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_nmaBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_nmaBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_nmaBrg.Location = New System.Drawing.Point(30, 200)
        Me.txt_nmaBrg.Name = "txt_nmaBrg"
        Me.txt_nmaBrg.Size = New System.Drawing.Size(494, 26)
        Me.txt_nmaBrg.TabIndex = 66
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 181)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 16)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Nama Barang:"
        '
        'txt_kodeBrg
        '
        Me.txt_kodeBrg.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_kodeBrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_kodeBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_kodeBrg.Location = New System.Drawing.Point(30, 142)
        Me.txt_kodeBrg.Name = "txt_kodeBrg"
        Me.txt_kodeBrg.Size = New System.Drawing.Size(494, 26)
        Me.txt_kodeBrg.TabIndex = 64
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(26, 123)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 16)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Kode Barang:"
        '
        'btn_delBrg
        '
        Me.btn_delBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(218, Byte), Integer), CType(CType(59, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.btn_delBrg.FlatAppearance.BorderSize = 0
        Me.btn_delBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_delBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_delBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_delBrg.Location = New System.Drawing.Point(284, 557)
        Me.btn_delBrg.Name = "btn_delBrg"
        Me.btn_delBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_delBrg.Size = New System.Drawing.Size(240, 29)
        Me.btn_delBrg.TabIndex = 88
        Me.btn_delBrg.Text = "Batal 🗑️"
        Me.btn_delBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_delBrg.UseVisualStyleBackColor = False
        '
        'btn_simpanBrg
        '
        Me.btn_simpanBrg.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(101, Byte), Integer))
        Me.btn_simpanBrg.FlatAppearance.BorderSize = 0
        Me.btn_simpanBrg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_simpanBrg.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_simpanBrg.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_simpanBrg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_simpanBrg.Location = New System.Drawing.Point(30, 557)
        Me.btn_simpanBrg.Name = "btn_simpanBrg"
        Me.btn_simpanBrg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_simpanBrg.Size = New System.Drawing.Size(240, 29)
        Me.btn_simpanBrg.TabIndex = 87
        Me.btn_simpanBrg.Text = "Simpan 💾"
        Me.btn_simpanBrg.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_simpanBrg.UseVisualStyleBackColor = False
        '
        'txt_barcodeValue
        '
        Me.txt_barcodeValue.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txt_barcodeValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_barcodeValue.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_barcodeValue.Location = New System.Drawing.Point(30, 84)
        Me.txt_barcodeValue.Name = "txt_barcodeValue"
        Me.txt_barcodeValue.Size = New System.Drawing.Size(242, 26)
        Me.txt_barcodeValue.TabIndex = 90
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(27, 65)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(58, 16)
        Me.Label84.TabIndex = 89
        Me.Label84.Text = "Barcode:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(281, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 16)
        Me.Label3.TabIndex = 92
        Me.Label3.Text = "Tipe Barcode:"
        '
        'cbo_tipeBarcode
        '
        Me.cbo_tipeBarcode.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_tipeBarcode.FormattingEnabled = True
        Me.cbo_tipeBarcode.Items.AddRange(New Object() {"Generate Barcode", "Barcode dari Barang"})
        Me.cbo_tipeBarcode.Location = New System.Drawing.Point(284, 84)
        Me.cbo_tipeBarcode.Name = "cbo_tipeBarcode"
        Me.cbo_tipeBarcode.Size = New System.Drawing.Size(240, 26)
        Me.cbo_tipeBarcode.TabIndex = 91
        '
        'btn_printBarcodeBarang
        '
        Me.btn_printBarcodeBarang.BackColor = System.Drawing.Color.FromArgb(CType(CType(34, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.btn_printBarcodeBarang.FlatAppearance.BorderSize = 0
        Me.btn_printBarcodeBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_printBarcodeBarang.Font = New System.Drawing.Font("Tahoma", 11.25!)
        Me.btn_printBarcodeBarang.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btn_printBarcodeBarang.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_printBarcodeBarang.Location = New System.Drawing.Point(476, 487)
        Me.btn_printBarcodeBarang.Name = "btn_printBarcodeBarang"
        Me.btn_printBarcodeBarang.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_printBarcodeBarang.Size = New System.Drawing.Size(48, 50)
        Me.btn_printBarcodeBarang.TabIndex = 93
        Me.btn_printBarcodeBarang.Text = "Print 🖨️"
        Me.btn_printBarcodeBarang.UseVisualStyleBackColor = False
        '
        'frm_PopUpBarangBaru
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(550, 605)
        Me.Controls.Add(Me.btn_printBarcodeBarang)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbo_tipeBarcode)
        Me.Controls.Add(Me.txt_barcodeValue)
        Me.Controls.Add(Me.Label84)
        Me.Controls.Add(Me.btn_delBrg)
        Me.Controls.Add(Me.btn_simpanBrg)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.txt_namaSup)
        Me.Controls.Add(Me.cbo_idSup)
        Me.Controls.Add(Me.txt_hrgaBeli)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txt_minStok)
        Me.Controls.Add(Me.txt_stok)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.btn_tmbhSatuan)
        Me.Controls.Add(Me.btn_tmbhKategori)
        Me.Controls.Add(Me.pic_barcodeBrg)
        Me.Controls.Add(Me.lblgenerateBarcode)
        Me.Controls.Add(Me.cbo_satuanBrg)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.cbo_kategoriBrg)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_hrgaBrg)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_nmaBrg)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_kodeBrg)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.closeBtn)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_PopUpBarangBaru"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_PopUpBarangBaru"
        CType(Me.pic_barcodeBrg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents closeBtn As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txt_namaSup As TextBox
    Friend WithEvents cbo_idSup As ComboBox
    Friend WithEvents txt_hrgaBeli As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txt_minStok As TextBox
    Friend WithEvents txt_stok As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents btn_tmbhSatuan As Button
    Friend WithEvents btn_tmbhKategori As Button
    Friend WithEvents pic_barcodeBrg As PictureBox
    Friend WithEvents lblgenerateBarcode As Label
    Friend WithEvents cbo_satuanBrg As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cbo_kategoriBrg As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_hrgaBrg As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_nmaBrg As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_kodeBrg As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btn_delBrg As Button
    Friend WithEvents btn_simpanBrg As Button
    Friend WithEvents txt_barcodeValue As TextBox
    Friend WithEvents Label84 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cbo_tipeBarcode As ComboBox
    Friend WithEvents btn_printBarcodeBarang As Button
End Class

﻿Imports MySql.Data.MySqlClient
Imports System.IO
Imports MessagingToolkit.Barcode
Imports System.Drawing.Printing
Imports Microsoft.VisualBasic.Devices

Public Class frm_ManageBarang

    Dim supplierIdToName As New Dictionary(Of String, String)
    Dim supplierNameToId As New Dictionary(Of String, String)
    Dim WithEvents PD As New PrintDocument
    Dim PPD As New PrintPreviewDialog

    Private isLoadingData As Boolean = False
    Private isFilterReady As Boolean = False
    Dim isManualBarcodeInput As Boolean = False

    Private Sub frm_ManageBarang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dbconn()

        load_kategoriBarang()
        load_satuanBarang()
        load_Barang()
        load_supplier()
        load_barangMassal()
        LoadSupplierToCombo()
        headerSelectAll.Visible = False
        pic_barcodeBrng.Visible = False
        btn_printBarcodeBarang.Visible = False
        lblbarcode.Visible = False
        isFilterReady = True
        Me.MaximizeBox = False
        Me.Size = New Size(1366, 768)  ' choose any width you want
        dgv_Barang.RowTemplate.Height = 30
        dgv_barangUbahMassal.RowTemplate.Height = 30
        txt_barcodeValue.Focus()
        GenerateKodeBarang()
    End Sub

    Sub GenerateKodeBarang()
        Dim prefix As String = "IM-BRG-"
        Dim newIncrement As Integer = 1

        Try
            If conn.State = ConnectionState.Open Then conn.Close()
            conn.Open()

            Dim query As String =
            "SELECT IFNULL(MAX(CAST(RIGHT(kode_barang,3) AS UNSIGNED)),0)
             FROM tblbarang
             WHERE kode_barang LIKE 'IM-BRG-%'"

            Dim cmd As New MySqlCommand(query, conn)
            Dim result = cmd.ExecuteScalar()

            newIncrement = CInt(result) + 1

        Catch ex As Exception
            MsgBox("Error generate kode barang: " & ex.Message)
        Finally
            conn.Close()
        End Try

        txt_kodeBrg.Text = prefix & newIncrement.ToString("000")
        txt_kodeBrg.ReadOnly = True
    End Sub

    Sub LoadSupplierToCombo()
        cbo_filterbySupplier.Items.Clear()
        supplierNameToId.Clear()

        ' 👉 item kosong = reset filter
        cbo_filterbySupplier.Items.Add("-- Semua Supplier --")
        supplierNameToId("-- Semua Supplier --") = Nothing

        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT supplier_ID, nama_supplier FROM tblsupplier", conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim id As String = dr("supplier_ID").ToString()
                Dim nama As String = dr("nama_supplier").ToString()

                cbo_filterbySupplier.Items.Add(nama)
                supplierNameToId(nama) = id
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        ' default pilih semua
        cbo_filterbySupplier.SelectedIndex = 0
    End Sub

    Sub load_supplier()
        cbo_IDSup.Items.Clear()
        supplierIdToName.Clear()

        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT supplier_ID, nama_supplier FROM tblsupplier", conn)
            dr = cmd.ExecuteReader
            While dr.Read
                Dim id As String = dr("supplier_ID").ToString()
                Dim nama As String = dr("nama_supplier").ToString()

                cbo_IDSup.Items.Add(id)           ' Display name
                supplierIdToName(id) = nama              ' Store ID for later
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Sub load_kategoriBarang()
        cbo_kategoriBrg.Items.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT * from `tblkategori`", conn)
            dr = cmd.ExecuteReader
            While dr.Read = True
                cbo_kategoriBrg.Items.Add(dr.Item("nma_kategori").ToString)
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Sub load_satuanBarang()
        cbo_satuanBrg.Items.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT * from `tblsatuan`", conn)
            dr = cmd.ExecuteReader
            While dr.Read = True
                cbo_satuanBrg.Items.Add(dr.Item("nma_satuan").ToString)
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Sub load_Barang()
        dgv_Barang.Rows.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT `kode_barang`, `barcode_value`, `barcode_type`, `nama_barang`, `kategori_barang`, `satuan_barang`, `harga_beli`, `harga_barang`, `stok`, `min_stok`, `barcode`, `supplier_ID`, `nama_supplier` FROM `tblbarang`", conn)
            dr = cmd.ExecuteReader
            While dr.Read
                dgv_Barang.Rows.Add(dgv_Barang.Rows.Count + 1, dr.Item("kode_barang"), dr.Item("barcode_value"), dr.Item("barcode_type"), dr.Item("nama_barang"), dr.Item("kategori_barang"), dr.Item("satuan_barang"), dr.Item("harga_beli"), dr.Item("harga_barang"), dr.Item("stok"), dr.Item("min_stok"), dr.Item("barcode"), dr.Item("supplier_ID"), dr.Item("nama_supplier"))
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Sub clear()
        GenerateKodeBarang()
        txt_nmaBrg.Clear()
        cbo_kategoriBrg.SelectedIndex = -1
        cbo_satuanBrg.SelectedIndex = -1
        cbo_IDSup.SelectedIndex = -1
        txt_namaSup.Clear()
        txt_hrgaBrg.Clear()
        txt_hrgaBeli.Clear()
        txt_stok.Clear()
        txt_minStok.Clear()
        pic_barcodeBrng.Image = Nothing
        txt_cariBrg.Clear()
        txt_barcodeValue.Clear()
        txt_barcodeValue.Focus()
        cbo_tipeBarcode.SelectedIndex = -1
    End Sub

    Function cekBarangViaKode(kode As String) As Boolean
        Dim ada As Boolean = False

        Try
            conn.Open()
            Dim cmd As New MySqlCommand("SELECT COUNT(*) FROM tblbarang WHERE kode_barang=@kode", conn)
            cmd.Parameters.AddWithValue("@kode", kode)

            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            ada = (count > 0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        Return ada
    End Function

    Sub GenerateBarcodeFromKode()
        If txt_barcodeValue.Text = "" Then Exit Sub

        Dim gen As New MessagingToolkit.Barcode.BarcodeEncoder
        gen.BackColor = Color.White

        pic_barcodeBrng.Image =
        New Bitmap(gen.Encode(BarcodeFormat.Code128, txt_barcodeValue.Text))
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        If MsgBox("Are you sure you want to exit?", vbInformation + vbYesNo) = vbYes Then
            Application.Exit()
        Else
            Return
        End If
    End Sub

    Sub ApplyBarcodeUIByType()
        Select Case cbo_tipeBarcode.Text
            Case "Generate Barcode"
                pic_barcodeBrng.Visible = True
                btn_printBarcodeBarang.Visible = True
                lblbarcode.Visible = True

                ' generate ulang barcode dari value
                GenerateBarcodeFromKode()

            Case "Barcode dari Barang"
                pic_barcodeBrng.Visible = False
                btn_printBarcodeBarang.Visible = False
                lblbarcode.Visible = False

                pic_barcodeBrng.Image = Nothing
        End Select
    End Sub


    Private Sub dgv_Barang_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_Barang.CellClick
        If e.RowIndex < 0 Then Exit Sub
        Try
            isLoadingData = True

            With dgv_Barang.Rows(e.RowIndex)
                txt_kodeBrg.Text = .Cells("colKodeBarang").Value.ToString()
                txt_barcodeValue.Text = .Cells("colNoBarcode").Value.ToString()
                cbo_tipeBarcode.Text = .Cells("colTipeBarcode").Value.ToString()
                txt_nmaBrg.Text = .Cells("colNamaBarang").Value.ToString()
                cbo_kategoriBrg.Text = .Cells("colKategoriBarang").Value.ToString()
                cbo_satuanBrg.Text = .Cells("colSatuanBarang").Value.ToString()
                txt_hrgaBeli.Text = .Cells("colHrgaBeli").Value.ToString()
                txt_hrgaBrg.Text = .Cells("colHargaJualBarang").Value.ToString()
                txt_stok.Text = .Cells("colStok").Value.ToString()
                txt_minStok.Text = .Cells("colMinStok").Value.ToString()

                If Not IsDBNull(.Cells(11).Value) Then
                    Dim imgBytes As Byte() = CType(.Cells(11).Value, Byte())
                    Using ms As New MemoryStream(imgBytes)
                        pic_barcodeBrng.Image = Image.FromStream(ms)
                    End Using
                Else
                    pic_barcodeBrng.Image = Nothing
                End If

                cbo_IDSup.Text = .Cells("colSupplierID").Value.ToString()
                txt_namaSup.Text = .Cells("colSupplierNama").Value.ToString()
            End With

            ' 🔥 PENTING
            ApplyBarcodeUIByType()

        Catch ex As Exception
            MsgBox(ex.Message, vbExclamation)
        Finally
            isLoadingData = False
        End Try
    End Sub


    Private Sub btnKembali_Click(sender As Object, e As EventArgs) Handles btnKembali.Click
        mainForm_Admin.Show()
        Me.Close()
    End Sub

    Private Sub txt_cariBrg_MouseClick(sender As Object, e As MouseEventArgs) Handles txt_cariBrg.MouseClick
        GenerateKodeBarang()
        txt_nmaBrg.Clear()
        cbo_kategoriBrg.SelectedIndex = -1
        cbo_satuanBrg.SelectedIndex = -1
        cbo_IDSup.SelectedIndex = -1
        txt_namaSup.Clear()
        txt_hrgaBrg.Clear()
        txt_hrgaBeli.Clear()
        txt_stok.Clear()
        txt_minStok.Clear()
        pic_barcodeBrng.Image = Nothing
        txt_barcodeValue.Clear()
        cbo_tipeBarcode.SelectedIndex = -1
    End Sub

    Private Sub btnStokBarang_Click(sender As Object, e As EventArgs) Handles btnStokBarang.Click
        frm_ManageStok.Show()
        Me.Close()
    End Sub

    Private Sub btnManageUser_Click(sender As Object, e As EventArgs) Handles btnManageUser.Click
        frm_ManageUsers.Show()
        Me.Close()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        If MsgBox("Yakin ingin logout?", vbInformation + vbYesNo) = vbYes Then
            Me.Close()
            loginForm.Show()
        Else
            Return
        End If
    End Sub

    Private Sub btnPembelian_Click(sender As Object, e As EventArgs) Handles btnPembelian.Click
        frm_ManagePembelian.Show()
        Me.Hide()
    End Sub

    Private Sub btnPengembalian_Click(sender As Object, e As EventArgs) Handles btnPengembalian.Click
        frm_ManagePengembalian.Show()
        Me.Hide()
    End Sub

    Private Sub btnPenjualan_Click(sender As Object, e As EventArgs) Handles btnPenjualan.Click
        frm_ManagePenjualan.Show()
        Me.Hide()
    End Sub

    Private Sub PD_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PD.PrintPage

        Dim f12 As New Font("Calibri", 12, FontStyle.Bold)
        Dim f10 As New Font("Calibri", 10, FontStyle.Regular)

        Dim left As Integer = 10
        Dim y As Integer = 10

        ' Judul kecil
        e.Graphics.DrawString("BARCODE", f12, Brushes.Black, left, y)
        y += 20

        ' Nama Barang bila ingin
        e.Graphics.DrawString(txt_nmaBrg.Text, f10, Brushes.Black, left, y)
        y += 15

        ' Gambar barcode
        Dim bc As Image = pic_barcodeBrng.Image
        e.Graphics.DrawImage(bc, left, y, bc.Width, bc.Height)

        'For i As Integer = 1 To banyakBarcode
        '    e.Graphics.DrawImage(pic_barcodeBrg.Image, left, y)
        '    y += pic_barcodeBrg.Image.Height + 20
        'Next
    End Sub

    Sub load_barangMassal()
        dgv_barangUbahMassal.Rows.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT 
                    `kode_barang`, 
                    `barcode_value`, 
                    `barcode_type`,
                    `nama_barang`, 
                    `satuan_barang`, 
                    `harga_beli`, 
                    `harga_barang`, 
                    `stok`, 
                    `min_stok`, 
                    `supplier_ID`, 
                    `nama_supplier`
                     FROM `tblbarang` 
                     ", conn)
            dr = cmd.ExecuteReader
            While dr.Read = True
                dgv_barangUbahMassal.Rows.Add(dgv_barangUbahMassal.Rows.Count + 1,
                                             False,
                                             dr.Item("kode_barang"),
                                             dr.Item("barcode_value"),
                                             dr.Item("barcode_type"),
                                             dr.Item("nama_barang"),
                                             dr.Item("satuan_barang"),
                                             dr.Item("harga_beli"),
                                             dr.Item("harga_barang"),
                                             dr.Item("stok"),
                                             dr.Item("min_stok"),
                                             dr.Item("supplier_ID"),
                                             dr.Item("nama_supplier"))
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub
    Sub LoadBarangBySupplier(idSupplier As String)
        Try
            If conn.State = ConnectionState.Closed Then conn.Open()

            Dim sql As String =
            "SELECT kode_barang, barcode_value, barcode_type,
                    nama_barang, kategori_barang, satuan_barang, 
                    harga_beli, harga_barang, stok, min_stok, barcode, 
                    supplier_ID, nama_supplier 
             FROM tblbarang 
             WHERE supplier_ID = @id"

            Dim cmd As New MySqlCommand(sql, conn)
            cmd.Parameters.AddWithValue("@id", idSupplier)

            Dim dr As MySqlDataReader = cmd.ExecuteReader()

            dgv_barangUbahMassal.Rows.Clear()

            Dim nomor As Integer = 1

            While dr.Read()
                Dim idx As Integer = dgv_barangUbahMassal.Rows.Add()
                With dgv_barangUbahMassal.Rows(idx)
                    .Cells("colNo").Value = nomor          ' Row Numbering
                    .Cells("colPilih").Value = False
                    .Cells("colKodeBarangMassal").Value = dr("kode_barang").ToString()
                    .Cells("colNoBarcodeMassal").Value = dr("barcode_value").ToString()
                    .Cells("colTipeBarcodeMassal").Value = dr("barcode_type").ToString()
                    .Cells("colNamaBarangMassal").Value = dr("nama_barang").ToString()
                    .Cells("colSatuanBarangMassal").Value = dr("satuan_barang").ToString()
                    .Cells("colHargaBeli").Value = dr("harga_beli").ToString()
                    .Cells("colHargaBarangMassal").Value = dr("harga_barang").ToString()
                    .Cells("colStokBarangMassal").Value = dr("stok").ToString()
                    .Cells("colMinStokBarangMassal").Value = dr("min_stok").ToString()
                    .Cells("colSupplierIDMassal").Value = dr("supplier_ID").ToString()
                    .Cells("colSupplierNamaMassal").Value = dr("nama_supplier").ToString()
                    nomor += 1
                End With

            End While

            headerSelectAll.Visible = (dgv_barangUbahMassal.Rows.Count > 0)

            If dgv_barangUbahMassal.Columns.Contains("colPilih") Then
                dgv_barangUbahMassal.Columns("colPilih").Visible = True
            End If

        Catch ex As Exception
            MsgBox("Gagal memfilter data: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub cbo_filterbySupplier_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_filterbySupplier.SelectedIndexChanged
        If Not isFilterReady Then Exit Sub

        txtcariHargaMassal.Clear()
        txtcariHargaMassal.Focus()


        If cbo_filterbySupplier.SelectedIndex <= 0 Then
            ' 👉 item kosong / semua supplier
            load_barangMassal()
            headerSelectAll.Visible = False
            If dgv_barangUbahMassal.Columns.Contains("colPilih") Then
                dgv_barangUbahMassal.Columns("colPilih").Visible = False
            End If
            Exit Sub
        End If

        Dim namaSupplier As String = cbo_filterbySupplier.Text
        Dim supplierId As Integer = supplierNameToId(namaSupplier)

        LoadBarangBySupplier(supplierId)
    End Sub


    Private Sub btn_ResetFilter_Click(sender As Object, e As EventArgs) Handles btn_ResetFilter.Click
        ' Reset ComboBox
        cbo_filterbySupplier.SelectedIndex = 0

        ' Reload semua barang tanpa filter
        load_barangMassal()

        headerSelectAll.Visible = False

        If dgv_barangUbahMassal.Columns.Contains("colPilih") Then
            dgv_barangUbahMassal.Columns("colPilih").Visible = False
        End If
    End Sub

    Private Sub btnUbahMassal_Click(sender As Object, e As EventArgs) Handles btnUbahMassal.Click
        Dim listBarang As New List(Of ubahMassal)

        For Each row As DataGridViewRow In dgv_barangUbahMassal.Rows
            If row.IsNewRow Then Continue For

            If row.Cells("colPilih").Value = True Then
                listBarang.Add(New ubahMassal With {
                .kode = row.Cells("colKodeBarangMassal").Value.ToString(),
                .nama = row.Cells("colNamaBarangMassal").Value.ToString(),
                .hargaBeli = CDec(row.Cells("colHargaBeli").Value),
                .hargaJual = CDec(row.Cells("colHargaBarangMassal").Value)
            })
            End If
        Next

        If listBarang.Count = 0 Then
            MsgBox("Tidak ada barang dipilih!", vbExclamation)
            Exit Sub
        End If

        Dim popup As New frm_PopUpUbahHargaMassal(listBarang)
        popup.ShowDialog()
    End Sub

    Private Sub btn_tmbhKategori_Click_1(sender As Object, e As EventArgs) Handles btn_tmbhKategori.Click
        frm_tbhKategori.ShowDialog()
    End Sub

    Private Sub btn_tmbhSatuan_Click_1(sender As Object, e As EventArgs) Handles btn_tmbhSatuan.Click
        frm_tbhSatuan.ShowDialog()
    End Sub

    Private Sub cbo_IDSup_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles cbo_IDSup.SelectedIndexChanged
        If cbo_IDSup.SelectedIndex = -1 Then Exit Sub

        Dim id As String = cbo_IDSup.SelectedItem.ToString()

        If supplierIdToName.ContainsKey(id) Then
            txt_namaSup.Text = supplierIdToName(id)
        Else
            txt_namaSup.Clear()
        End If
    End Sub

    Private Sub btn_printBarcodeBarang_Click_1(sender As Object, e As EventArgs) Handles btn_printBarcodeBarang.Click
        If pic_barcodeBrng.Image Is Nothing Then
            MsgBox("Barcode belum dibuat!", vbExclamation)
            Exit Sub
        End If

        PD.DefaultPageSettings.PaperSize = New PaperSize("Custom", 300, 180)

        PPD.Document = PD
        PPD.Width = 600
        PPD.Height = 800

        PPD.ShowDialog()
    End Sub

    Private Sub btn_simpanBrg_Click_1(sender As Object, e As EventArgs) Handles btn_simpanBrg.Click
        Try
            If cekBarangViaKode(txt_kodeBrg.Text) Then
                MsgBox("Kode barang sudah terdaftar! Gunakan tombol UPDATE untuk mengubah data.", vbExclamation)
                Exit Sub
            End If

            If String.IsNullOrWhiteSpace(txt_barcodeValue.Text) Then
                MsgBox("Barcode belum diisi / discan!", vbExclamation)
                Exit Sub
            End If

            conn.Open()
            Dim arrImage() As Byte = Nothing
            If cbo_tipeBarcode.Text = "Generate Barcode" Then
                If pic_barcodeBrng.Image IsNot Nothing Then
                    Using mstream As New MemoryStream()
                        pic_barcodeBrng.Image.Save(mstream, Imaging.ImageFormat.Png)
                        arrImage = mstream.ToArray()
                    End Using
                End If
            End If

            cmd = New MySqlCommand("INSERT INTO `tblbarang`(`kode_barang`, `barcode_value`, `barcode_type`, `nama_barang`, `kategori_barang`, `satuan_barang`, `harga_beli`, `harga_barang`, `stok`, `min_stok`, `barcode`, `supplier_ID`, `nama_supplier`) VALUES (@kode_barang, @barcode_value, @barcode_type, @nama_barang, @kategori_barang, @satuan_barang, @harga_beli, @harga_barang, @stok, @min_stok, @barcode, @supplier_ID, @nama_supplier)", conn)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@kode_barang", txt_kodeBrg.Text)
            cmd.Parameters.AddWithValue("@barcode_value", txt_barcodeValue.Text)
            cmd.Parameters.AddWithValue("@barcode_type", cbo_tipeBarcode.Text)
            cmd.Parameters.AddWithValue("@nama_barang", txt_nmaBrg.Text)
            cmd.Parameters.AddWithValue("@kategori_barang", cbo_kategoriBrg.Text)
            cmd.Parameters.AddWithValue("@satuan_barang", cbo_satuanBrg.Text)
            cmd.Parameters.AddWithValue("@harga_beli", CDec(txt_hrgaBeli.Text))
            cmd.Parameters.AddWithValue("@harga_barang", CDec(txt_hrgaBrg.Text))
            cmd.Parameters.AddWithValue("@stok", txt_stok.Text)
            cmd.Parameters.AddWithValue("@min_stok", txt_minStok.Text)
            If arrImage IsNot Nothing Then
                cmd.Parameters.Add("@barcode", MySqlDbType.Blob).Value = arrImage
            Else
                cmd.Parameters.Add("@barcode", MySqlDbType.Blob).Value = DBNull.Value
            End If
            cmd.Parameters.AddWithValue("@supplier_ID", cbo_IDSup.Text)
            cmd.Parameters.AddWithValue("@nama_supplier", txt_namaSup.Text)

            i = cmd.ExecuteNonQuery
            If i > 0 Then
                MsgBox("Barang baru berhasil disimpan!", vbInformation)
            Else
                MsgBox("Barang gagal disimpan!", vbExclamation)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
        clear()
        load_Barang()
        frm_ManagePembelian.load_barang()
        GenerateKodeBarang()
    End Sub

    Private Sub btn_updateBrg_Click_1(sender As Object, e As EventArgs) Handles btn_updateBrg.Click
        Try
            conn.Open()
            cmd = New MySqlCommand("UPDATE `tblbarang` SET `barcode_value`=@barcode_value, `barcode_type`=@barcode_type, `nama_barang`=@nama_barang,`kategori_barang`=@kategori_barang,`satuan_barang`=@satuan_barang,`harga_beli`=@harga_beli,`harga_barang`=@harga_barang, `stok` =@stok, `min_stok`=@min_stok, `supplier_ID`=@supplier_ID, `nama_supplier`=@nama_supplier WHERE `kode_barang`=@kode_barang", conn)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@barcode_value", txt_barcodeValue.Text)
            cmd.Parameters.AddWithValue("@barcode_type", cbo_tipeBarcode.Text)
            cmd.Parameters.AddWithValue("@nama_barang", txt_nmaBrg.Text)
            cmd.Parameters.AddWithValue("@kategori_barang", cbo_kategoriBrg.Text)
            cmd.Parameters.AddWithValue("@satuan_barang", cbo_satuanBrg.Text)
            cmd.Parameters.AddWithValue("@harga_beli", CDec(txt_hrgaBeli.Text))
            cmd.Parameters.AddWithValue("@harga_barang", CDec(txt_hrgaBrg.Text))
            cmd.Parameters.AddWithValue("@stok", txt_stok.Text)
            cmd.Parameters.AddWithValue("@min_stok", txt_minStok.Text)
            cmd.Parameters.AddWithValue("@supplier_ID", cbo_IDSup.Text)
            cmd.Parameters.AddWithValue("@nama_supplier", txt_namaSup.Text)

            cmd.Parameters.AddWithValue("@kode_barang", txt_kodeBrg.Text)

            i = cmd.ExecuteNonQuery
            If i > 0 Then
                MsgBox("Barang berhasil diupdate!", vbInformation)
            Else
                MsgBox("Barang gagal diupdate!", vbExclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
        clear()
        txt_cariBrg.Clear()
        load_Barang()
        frm_ManagePembelian.load_barang()
    End Sub

    Private Sub btn_clearBrg_Click_1(sender As Object, e As EventArgs) Handles btn_clearBrg.Click
        clear()
    End Sub

    Private Sub btn_delBrg_Click_1(sender As Object, e As EventArgs) Handles btn_delBrg.Click
        If MsgBox("Apakah anda yakin ingin menghapus barang ini?", vbExclamation + vbYesNo) = vbYes Then
            Try
                conn.Open()
                cmd = New MySqlCommand("DELETE FROM `tblbarang` WHERE `kode_barang`=@kode_barang", conn)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@kode_barang", txt_kodeBrg.Text)

                i = cmd.ExecuteNonQuery
                If i > 0 Then
                    MsgBox("Barang berhasil dihapus!", vbInformation)
                Else
                    MsgBox("Barang gagal dihapus!", vbExclamation)
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            conn.Close()
            clear()
            txt_cariBrg.Clear()
            load_Barang()
            frm_ManagePembelian.load_barang()
        Else
            Return
        End If
    End Sub

    Private Sub cbo_tipeBarcode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_tipeBarcode.SelectedIndexChanged
        If isLoadingData Then Exit Sub   ' ⛔ abaikan jika dari dgv click

        pic_barcodeBrng.Image = Nothing
        txt_barcodeValue.Clear()

        Select Case cbo_tipeBarcode.Text
            Case "Generate Barcode"
                isManualBarcodeInput = False
                txt_barcodeValue.Clear()
                pic_barcodeBrng.Visible = True
                btn_printBarcodeBarang.Visible = True
                lblbarcode.Visible = True

                txt_barcodeValue.Text = txt_kodeBrg.Text

                ' Barcode diambil dari kode_barang
                GenerateBarcodeFromKode()

            Case "Barcode dari Barang"
                isManualBarcodeInput = True
                txt_barcodeValue.Enabled = True
                pic_barcodeBrng.Visible = False
                btn_printBarcodeBarang.Visible = False
                lblbarcode.Visible = False

                txt_barcodeValue.Focus()
        End Select
    End Sub

    Private Sub txt_barcodeValue_TextChanged(sender As Object, e As EventArgs) Handles txt_barcodeValue.TextChanged
        If isLoadingData Then Exit Sub

        If isManualBarcodeInput AndAlso Not String.IsNullOrWhiteSpace(txt_barcodeValue.Text) Then
            isLoadingData = True
            isManualBarcodeInput = True
            cbo_tipeBarcode.SelectedItem = "Barcode dari Barang"
            isLoadingData = False
        End If
    End Sub

    Private Sub btnSupplier_Click(sender As Object, e As EventArgs) Handles btnSupplier.Click
        frm_ManageSupplier.Show()
        Me.Close()
    End Sub

    Private Sub txt_barcodeValue_Enter(sender As Object, e As EventArgs) Handles txt_barcodeValue.Enter
        If isLoadingData Then Exit Sub

        isManualBarcodeInput = True
        cbo_tipeBarcode.SelectedItem = "Barcode dari Barang"
    End Sub

    Private Sub cbo_selectAllhargaMsl_CheckedChanged(sender As Object, e As EventArgs) Handles chk_selectAllhargaMsl.CheckedChanged
        For Each row As DataGridViewRow In dgv_barangUbahMassal.Rows
            row.Cells("colPilih").Value = chk_selectAllhargaMsl.Checked
        Next
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
        If TabControl1.SelectedTab Is TabPage1 Then
            Panel3.Visible = True
        ElseIf TabControl1.SelectedTab Is TabPage2 Then
            Panel3.Visible = False
        End If
    End Sub

    Private isScanMode As Boolean = True

    Private Sub txt_cariBrg_Enter(sender As Object, e As EventArgs) Handles txt_cariBrg.Enter
        isScanMode = False
    End Sub

    Private Sub frm_ManageBarang_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        If isScanMode Then
            txt_barcodeValue.Focus()
        End If
    End Sub

    Sub LoadBarangCari(keyword As String)
        dgv_Barang.Rows.Clear()
        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT 
                                        kode_barang,
                                        barcode_value,
                                        barcode_type,
                                        nama_barang,
                                        kategori_barang,
                                        satuan_barang,
                                        harga_beli,
                                        harga_barang,
                                        stok,
                                        min_stok,
                                        barcode,
                                        supplier_ID,
                                        nama_supplier
                                    FROM tblbarang
                                    WHERE kode_barang LIKE @key
                                       OR barcode_value LIKE @key
                                       OR nama_barang LIKE @key
                                       OR kategori_barang LIKE @key", conn)


            cmd.Parameters.AddWithValue("@key", "%" & keyword & "%")

            dr = cmd.ExecuteReader
            While dr.Read
                dgv_Barang.Rows.Add(
                dgv_Barang.Rows.Count + 1,
                dr("kode_barang"),
                dr("barcode_value"),
                dr("barcode_type"),
                dr("nama_barang"),
                dr("kategori_barang"),
                dr("satuan_barang"),
                dr("harga_beli"),
                dr("harga_barang"),
                dr("stok"),
                dr("min_stok"),
                dr("barcode"),
                dr("supplier_ID"),
                dr("nama_supplier")
            )
            End While

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub


    Private Sub txt_cariBrg_KeyUp(sender As Object, e As KeyEventArgs) Handles txt_cariBrg.KeyUp
        LoadBarangCari(txt_cariBrg.Text)
    End Sub
    Private Sub txt_cariBrg_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_cariBrg.KeyDown
        If e.KeyCode = Keys.Escape Then
            isScanMode = True
            txt_barcodeValue.Focus()
        End If
    End Sub

    Private Sub txtcariHargaMassal_KeyDown(sender As Object, e As KeyEventArgs) Handles txtcariHargaMassal.KeyDown
        If e.KeyCode = Keys.Escape Then
            isScanMode = True
            txt_barcodeValue.Focus()
        End If
    End Sub

    Private Sub txtcariHargaMassal_KeyUp(sender As Object, e As KeyEventArgs) Handles txtcariHargaMassal.KeyUp
        dgv_barangUbahMassal.Rows.Clear()
        Dim keyword = txtcariHargaMassal.Text
        Dim filterSup = cbo_filterbySupplier.Text

        Try
            conn.Open()
            cmd = New MySqlCommand("SELECT 
                                        kode_barang,
                                        barcode_value,
                                        barcode_type,
                                        nama_barang,
                                        satuan_barang,
                                        harga_beli,
                                        harga_barang,
                                        stok,
                                        min_stok,
                                        supplier_ID,
                                        nama_supplier
                                    FROM tblbarang
                                    WHERE nama_supplier LIKE @filter
                                    AND (
                                           kode_barang LIKE @key
                                        OR barcode_value LIKE @key
                                        OR nama_barang LIKE @key
                                        OR kategori_barang LIKE @key
                                    )", conn)


            cmd.Parameters.AddWithValue("@key", "%" & keyword & "%")
            cmd.Parameters.AddWithValue("@filter", "%" & filterSup & "%")

            dr = cmd.ExecuteReader
            While dr.Read
                dgv_barangUbahMassal.Rows.Add(
                dgv_barangUbahMassal.Rows.Count + 1,
                Nothing,
                dr("kode_barang"),
                dr("barcode_value"),
                dr("barcode_type"),
                dr("nama_barang"),
                dr("satuan_barang"),
                dr("harga_beli"),
                dr("harga_barang"),
                dr("stok"),
                dr("min_stok"),
                dr("supplier_ID"),
                dr("nama_supplier")
            )
            End While

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
End Class